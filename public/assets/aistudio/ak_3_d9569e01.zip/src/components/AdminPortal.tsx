import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  Mail,
  Plane,
  Plus,
  RefreshCw,
  Shield,
  ShieldCheck,
  Users,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  addAdminFlight,
  fetchAdminEmails,
  fetchAdminStats,
  fetchConfig,
  fetchFlights,
  fetchMyBookings,
  updateAdminFlight,
} from '../lib/api.ts';
import type { Booking, EmailLog, Flight } from '../types/index.ts';
import { EmailTestLab } from './EmailTestLab.tsx';

export function AdminPortal() {
  const { user, login } = useAuth();
  const isAdmin = user?.role === 'admin';

  // Admin sign-in form state if not authenticated as admin
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [loggingIn, setLoggingIn] = useState(false);

  // Tabs (including development test lab)
  const [activeTab, setActiveTab] = useState<'kpis' | 'test-lab' | 'emails' | 'flights' | 'bookings' | 'system'>('test-lab');

  // Data states
  const [stats, setStats] = useState<any>(null);
  const [emailLogs, setEmailLogs] = useState<EmailLog[]>([]);
  const [flights, setFlights] = useState<Flight[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [systemConfig, setSystemConfig] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  // Add flight form state
  const [showAddFlight, setShowAddFlight] = useState(false);
  const [newFlightNumber, setNewFlightNumber] = useState('AW-312');
  const [newOrigin, setNewOrigin] = useState('JFK');
  const [newDestination, setNewDestination] = useState('CDG');
  const [newAircraft, setNewAircraft] = useState('Boeing 787-9 Dreamliner');
  const [newEconomyPrice, setNewEconomyPrice] = useState(540);

  useEffect(() => {
    if (isAdmin) {
      loadAdminData();
    }
  }, [isAdmin]);

  const loadAdminData = async () => {
    setLoading(true);
    try {
      const email = user?.email;
      const [statsData, emailData, flightData, bookingData, configData] = await Promise.all([
        fetchAdminStats(email).catch(() => null),
        fetchAdminEmails(email).catch(() => []),
        fetchFlights().catch(() => []),
        fetchMyBookings().catch(() => []),
        fetchConfig().catch(() => null),
      ]);
      setStats(statsData);
      setEmailLogs(emailData);
      setFlights(flightData);
      setBookings(bookingData);
      setSystemConfig(configData);
    } catch (err) {
      console.error('Failed to load admin data', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAdminSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setLoggingIn(true);
    try {
      const loggedUser = await login(adminEmail.trim().toLowerCase(), adminPassword);
      if (loggedUser.role !== 'admin') {
        setAuthError('Access restricted: Authorized administrator account credentials required.');
      }
    } catch (err: any) {
      setAuthError(err.message || 'Administrator authentication failed. Please verify credentials.');
    } finally {
      setLoggingIn(false);
    }
  };

  const handleStatusChange = async (flightId: string, status: string) => {
    try {
      await updateAdminFlight(flightId, { status }, user?.email);
      setFlights((prev) => prev.map((f) => (f.id === flightId ? { ...f, status: status as any } : f)));
    } catch (err) {
      console.error('Failed to update flight status', err);
    }
  };

  const handleCreateFlight = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const created = await addAdminFlight({
        flightNumber: newFlightNumber,
        aircraft: newAircraft,
        originCode: newOrigin,
        destinationCode: newDestination,
        prices: {
          economy: Number(newEconomyPrice),
          premiumEconomy: Math.round(Number(newEconomyPrice) * 1.6),
          business: Math.round(Number(newEconomyPrice) * 3.2),
          first: Math.round(Number(newEconomyPrice) * 6),
        },
      }, user?.email);
      setFlights([created, ...flights]);
      setShowAddFlight(false);
    } catch (err) {
      console.error('Failed to create flight', err);
    }
  };

  // If not authenticated as administrator, show clean secure sign-in screen
  if (!isAdmin) {
    return (
      <div className="max-w-md mx-auto px-4 py-16">
        <div className="p-8 rounded-3xl bg-white border border-slate-200 shadow-xl space-y-6">
          <div className="text-center">
            <div className="w-12 h-12 mx-auto rounded-2xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-900 mb-3 shadow-xs">
              <Shield className="w-6 h-6" />
            </div>
            <span className="text-xs font-bold uppercase tracking-wider text-blue-900">Restricted Operations</span>
            <h2 className="text-2xl font-bold text-slate-900 mt-1">Admin Portal Sign In</h2>
            <p className="text-xs text-slate-500 mt-1">
              Authorized AeroWings flight operations and system administrators only
            </p>
          </div>

          {authError && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
              <span>{authError}</span>
            </div>
          )}

          <form onSubmit={handleAdminSignIn} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Admin Email</label>
              <input
                type="email"
                required
                value={adminEmail}
                onChange={(e) => setAdminEmail(e.target.value)}
                placeholder="administrator@domain.com"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-4 py-2.5 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-700 focus:bg-white transition-colors"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Admin Password</label>
              <input
                type="password"
                required
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-4 py-2.5 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-700 focus:bg-white transition-colors"
              />
            </div>
            <button
              type="submit"
              disabled={loggingIn}
              className="w-full py-3 px-4 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl transition-colors disabled:opacity-50 text-sm shadow-xs"
            >
              {loggingIn ? 'Authenticating Admin...' : 'Sign In as Administrator'}
            </button>
          </form>

          <p className="text-[11px] text-center text-slate-400">
            Administrative sessions are securely authenticated and audited server-side.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-blue-900 font-bold tracking-wider uppercase">
            <ShieldCheck className="w-4 h-4" />
            <span>Operations & Flight Management</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">Admin Portal</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Monitor real-time flight schedules, customer bookings, and outbound Resend email delivery
          </p>
        </div>

        <button
          onClick={loadAdminData}
          disabled={loading}
          className="flex items-center gap-2 px-3.5 py-2 bg-white hover:bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-700 shadow-xs transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-blue-900' : ''}`} />
          <span>Refresh Data</span>
        </button>
      </div>

      {/* Admin Tabs */}
      <div className="flex items-center gap-2 p-1.5 bg-slate-100 border border-slate-200 rounded-xl overflow-x-auto">
        <button
          onClick={() => setActiveTab('test-lab')}
          className={`px-4 py-2 text-xs font-bold rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'test-lab' ? 'bg-blue-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Mail className="w-3.5 h-3.5 text-blue-300" />
          <span>Email Test Lab & Sandbox</span>
          <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
            Free Dev Mode
          </span>
        </button>
        <button
          onClick={() => setActiveTab('kpis')}
          className={`px-4 py-2 text-xs font-bold rounded-lg whitespace-nowrap transition-colors ${
            activeTab === 'kpis' ? 'bg-blue-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Overview & Metrics
        </button>
        <button
          onClick={() => setActiveTab('emails')}
          className={`px-4 py-2 text-xs font-bold rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'emails' ? 'bg-blue-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Mail className="w-3.5 h-3.5" />
          <span>Resend Email Audit ({emailLogs.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('flights')}
          className={`px-4 py-2 text-xs font-bold rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'flights' ? 'bg-blue-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Plane className="w-3.5 h-3.5" />
          <span>Flight Schedules ({flights.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('bookings')}
          className={`px-4 py-2 text-xs font-bold rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'bookings' ? 'bg-blue-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Bookings ({bookings.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('system')}
          className={`px-4 py-2 text-xs font-bold rounded-lg whitespace-nowrap transition-colors ${
            activeTab === 'system' ? 'bg-blue-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          System Config
        </button>
      </div>

      {/* TAB 0: EMAIL TEST LAB & SANDBOX (Safe Free Development Testing) */}
      {activeTab === 'test-lab' && <EmailTestLab />}

      {/* TAB 1: OVERVIEW & KPIS */}
      {activeTab === 'kpis' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">Total Confirmed Revenue</span>
              <div className="text-2xl font-black text-slate-900 mt-1 font-mono">
                ${stats?.totalRevenue ? stats.totalRevenue.toLocaleString() : '0'} USD
              </div>
              <div className="text-[11px] text-emerald-700 font-semibold mt-1">Paid bookings in persistent database</div>
            </div>
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">Total Reservations</span>
              <div className="text-2xl font-black text-slate-900 mt-1 font-mono">
                {stats?.totalBookings || 0}
              </div>
              <div className="text-[11px] text-blue-900 font-semibold mt-1">
                {stats?.confirmedBookings || 0} confirmed • {stats?.cancelledBookings || 0} cancelled
              </div>
            </div>
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">Active Flight Schedules</span>
              <div className="text-2xl font-black text-slate-900 mt-1 font-mono">
                {stats?.activeFlights || flights.length}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">International & Domestic</div>
            </div>
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">Outbound Resend Emails</span>
              <div className="text-2xl font-black text-slate-900 mt-1 font-mono">
                {emailLogs.length}
              </div>
              <div className="text-[11px] text-emerald-700 font-semibold mt-1">
                OTPs & Booking confirmations
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: RESEND EMAIL AUDIT LOG */}
      {activeTab === 'emails' && (
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
          <div>
            <h3 className="text-lg font-bold text-slate-900">Outbound Resend Email Dispatch Log</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Tracks every email OTP, booking confirmation, and cancellation notice sent directly to each customer
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 uppercase font-bold">
                  <th className="py-3 px-3">Timestamp</th>
                  <th className="py-3 px-3">Recipient</th>
                  <th className="py-3 px-3">Type</th>
                  <th className="py-3 px-3">Subject / PNR</th>
                  <th className="py-3 px-3">Resend Status</th>
                  <th className="py-3 px-3">Message ID / Error</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {emailLogs.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-400">
                      No outbound emails logged yet. Initiate an OTP verification or booking to populate.
                    </td>
                  </tr>
                ) : (
                  emailLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50">
                      <td className="py-3 px-3 text-slate-500 font-mono whitespace-nowrap">
                        {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </td>
                      <td className="py-3 px-3 font-semibold text-slate-900">{log.to}</td>
                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-50 border border-blue-200 text-blue-900">
                          {log.type}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-slate-700 truncate max-w-xs">{log.subject}</td>
                      <td className="py-3 px-3">
                        {log.status === 'SENT' ? (
                          <span className="text-emerald-700 font-bold bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded text-[10px]">
                            SENT (Resend)
                          </span>
                        ) : log.status === 'SIMULATED' ? (
                          <span className="text-blue-700 font-bold bg-blue-50 border border-blue-200 px-2 py-0.5 rounded text-[10px]">
                            SIMULATED
                          </span>
                        ) : (
                          <span className="text-rose-700 font-bold bg-rose-50 border border-rose-200 px-2 py-0.5 rounded text-[10px]">
                            FAILED
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-3 text-slate-500 font-mono text-[11px] truncate max-w-xs">
                        {log.resendId || log.errorMessage || 'Delivered'}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: FLIGHT SCHEDULES */}
      {activeTab === 'flights' && (
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Flight Operations & Schedules</h3>
              <p className="text-xs text-slate-500 mt-0.5">Manage airline departures, arrival gates, and status</p>
            </div>
            <button
              onClick={() => setShowAddFlight(!showAddFlight)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Schedule</span>
            </button>
          </div>

          {showAddFlight && (
            <form onSubmit={handleCreateFlight} className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
              <h4 className="text-xs font-bold uppercase text-blue-900">Add New Flight Route</h4>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Flight Number</label>
                  <input
                    type="text"
                    value={newFlightNumber}
                    onChange={(e) => setNewFlightNumber(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Origin Code</label>
                  <input
                    type="text"
                    value={newOrigin}
                    onChange={(e) => setNewOrigin(e.target.value.toUpperCase())}
                    className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Destination Code</label>
                  <input
                    type="text"
                    value={newDestination}
                    onChange={(e) => setNewDestination(e.target.value.toUpperCase())}
                    className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Aircraft</label>
                  <input
                    type="text"
                    value={newAircraft}
                    onChange={(e) => setNewAircraft(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Base Price ($ USD)</label>
                  <input
                    type="number"
                    value={newEconomyPrice}
                    onChange={(e) => setNewEconomyPrice(Number(e.target.value))}
                    className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-900"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddFlight(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 text-xs text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3 py-1.5 rounded-lg bg-blue-900 text-white font-bold text-xs"
                >
                  Save Schedule
                </button>
              </div>
            </form>
          )}

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 uppercase font-bold">
                  <th className="py-3 px-3">Flight</th>
                  <th className="py-3 px-3">Route</th>
                  <th className="py-3 px-3">Departure</th>
                  <th className="py-3 px-3">Aircraft</th>
                  <th className="py-3 px-3">Base Fare</th>
                  <th className="py-3 px-3">Status</th>
                  <th className="py-3 px-3">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {flights.map((flight) => (
                  <tr key={flight.id} className="hover:bg-slate-50">
                    <td className="py-3 px-3 font-mono font-bold text-blue-900">{flight.flightNumber}</td>
                    <td className="py-3 px-3 font-semibold text-slate-900">
                      {flight.origin.code} → {flight.destination.code}
                    </td>
                    <td className="py-3 px-3 text-slate-500">
                      {new Date(flight.departureTime).toLocaleDateString([], { month: 'short', day: 'numeric' })}{' '}
                      {new Date(flight.departureTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>
                    <td className="py-3 px-3 text-slate-600">{flight.aircraft}</td>
                    <td className="py-3 px-3 font-mono text-slate-700">${flight.prices.economy} USD</td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 border border-emerald-200 text-emerald-800">
                        {flight.status}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <select
                        value={flight.status}
                        onChange={(e) => handleStatusChange(flight.id, e.target.value)}
                        className="bg-white border border-slate-300 rounded px-2 py-1 text-[11px] text-slate-800"
                      >
                        <option value="SCHEDULED">Scheduled</option>
                        <option value="BOARDING">Boarding</option>
                        <option value="DEPARTED">Departed</option>
                        <option value="DELAYED">Delayed</option>
                        <option value="CANCELLED">Cancelled</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: BOOKINGS */}
      {activeTab === 'bookings' && (
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
          <div>
            <h3 className="text-lg font-bold text-slate-900">All Database Bookings</h3>
            <p className="text-xs text-slate-500 mt-0.5">Complete airline passenger reservations roster</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 uppercase font-bold">
                  <th className="py-3 px-3">PNR</th>
                  <th className="py-3 px-3">Customer Email</th>
                  <th className="py-3 px-3">Flight</th>
                  <th className="py-3 px-3">Travelers</th>
                  <th className="py-3 px-3">Total Amount</th>
                  <th className="py-3 px-3">Status</th>
                  <th className="py-3 px-3">Verification Token</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {bookings.map((b) => (
                  <tr key={b.id} className="hover:bg-slate-50">
                    <td className="py-3 px-3 font-mono font-bold text-blue-900">{b.pnr}</td>
                    <td className="py-3 px-3 text-slate-800 font-medium">{b.contactEmail}</td>
                    <td className="py-3 px-3 text-slate-900">
                      {b.flight.origin.code} → {b.flight.destination.code} ({b.flight.flightNumber})
                    </td>
                    <td className="py-3 px-3 text-slate-600">{b.passengers.length} pax</td>
                    <td className="py-3 px-3 font-mono font-bold text-slate-900">
                      ${b.fareBreakdown.totalAmount.toFixed(2)} USD
                    </td>
                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        b.bookingStatus === 'CONFIRMED'
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          : 'bg-rose-50 text-rose-800 border border-rose-200'
                      }`}>
                        {b.bookingStatus}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono text-[10px] text-slate-500 truncate max-w-[120px]">
                      {b.verificationToken}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: SYSTEM CONFIG */}
      {activeTab === 'system' && (
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
          <div>
            <h3 className="text-lg font-bold text-slate-900">System & Resend Configuration</h3>
            <p className="text-xs text-slate-500 mt-0.5">Secure server environment inspection</p>
          </div>
          <div className="space-y-3 text-xs">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-slate-500 block">Deployed Website Domain (APP_URL):</span>
                <span className="font-mono text-slate-900 text-sm font-bold">
                  {systemConfig?.appUrl || window.location.origin}
                </span>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Used for authentic QR code verification link resolution: {systemConfig?.appUrl || window.location.origin}/booking/verify/:token
                </p>
              </div>
              <span className="px-2.5 py-1 rounded bg-blue-50 border border-blue-200 text-blue-900 font-bold text-[10px]">
                ACTIVE
              </span>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-slate-500 block">Resend Email Integration:</span>
                <span className="font-semibold text-slate-900">
                  Sender: {systemConfig?.resendFromEmail || 'AeroWings <onboarding@resend.dev>'}
                </span>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  API Key: {systemConfig?.resendConfigured ? 'Configured & Authenticated (starts with re_)' : 'Preview Simulation Mode (Live logs captured below)'}
                </p>
              </div>
              <span className={`px-2.5 py-1 rounded border font-bold text-[10px] ${
                systemConfig?.resendConfigured
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                  : 'bg-blue-50 border-blue-200 text-blue-900'
              }`}>
                {systemConfig?.resendConfigured ? 'RESEND LIVE' : 'PREVIEW MODE'}
              </span>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-slate-500 block">Twilio / SMS Integration Status:</span>
                <span className="font-semibold text-slate-600">
                  Completely Decommissioned (Independent Email OTP Only)
                </span>
              </div>
              <span className="px-2.5 py-1 rounded bg-slate-100 border border-slate-200 text-slate-500 text-[10px]">
                REMOVED
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
