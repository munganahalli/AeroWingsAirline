import React, { useMemo, useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  Clock,
  Filter,
  Luggage,
  Plane,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import { useCurrency } from '../../context/CurrencyContext.tsx';
import { AirlineFilter } from '../Search/AirlineFilter.tsx';
import type { CabinClass, Flight } from '../../types/index.ts';

interface Step1Props {
  flights: Flight[];
  selectedFlight: Flight | null;
  selectedCabinClass: CabinClass;
  onSelectFlight: (flight: Flight, cabin: CabinClass) => void;
  onNext: () => void;
  onRequestSignIn?: (flight: Flight, cabin: CabinClass) => void;
}

export function Step1FlightSelection({
  flights,
  selectedFlight,
  selectedCabinClass,
  onSelectFlight,
  onNext,
  onRequestSignIn,
}: Step1Props) {
  const { user } = useAuth();
  const { formatPrice, currency } = useCurrency();
  const [filterStops, setFilterStops] = useState<'all' | 'direct'>('all');
  const [selectedAirlines, setSelectedAirlines] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState<'price' | 'duration' | 'departure'>('price');

  // List of airlines present in the current flight dataset
  const availableAirlinesInFlightData = useMemo(() => {
    return Array.from(new Set(flights.map((f) => f.airline)));
  }, [flights]);

  // Combined filtering: stops + airlines + cabin availability
  const filteredFlights = useMemo(() => {
    return flights
      .filter((f) => {
        // Stops filter
        if (filterStops === 'direct' && f.stops !== 0) return false;

        // Airline multi-select filter
        if (selectedAirlines.length > 0) {
          const match = selectedAirlines.some(
            (airline) => airline.trim().toLowerCase() === f.airline.trim().toLowerCase()
          );
          if (!match) return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'price') return a.prices[selectedCabinClass] - b.prices[selectedCabinClass];
        if (sortBy === 'departure')
          return new Date(a.departureTime).getTime() - new Date(b.departureTime).getTime();
        return a.duration.localeCompare(b.duration);
      });
  }, [flights, filterStops, selectedAirlines, sortBy, selectedCabinClass]);

  const cabinClasses: { key: CabinClass; label: string; badge: string }[] = [
    { key: 'economy', label: 'Economy', badge: 'Standard Cabin' },
    { key: 'premiumEconomy', label: 'Premium Economy', badge: 'Extra Recline' },
    { key: 'business', label: 'Business', badge: 'Lie-Flat & Lounge' },
    { key: 'first', label: 'First Class', badge: 'Private Suite' },
  ];

  const handleProceed = () => {
    if (!selectedFlight) return;
    if (!user) {
      if (onRequestSignIn) {
        onRequestSignIn(selectedFlight, selectedCabinClass);
      }
      return;
    }
    onNext();
  };

  return (
    <div className="space-y-6">
      {/* Top Filter and Info Bar */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <span>Step 1: Select Your Flight</span>
              {!user && (
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200">
                  Sign in required to book
                </span>
              )}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Showing {filteredFlights.length} matching schedules • Verified electronic ticket issuance
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* 100 Airline Filter Button */}
            <AirlineFilter
              selectedAirlines={selectedAirlines}
              onChange={setSelectedAirlines}
              availableAirlinesInFlightData={availableAirlinesInFlightData}
            />

            {/* Direct filter */}
            <div className="flex items-center p-1 bg-slate-100 border border-slate-200 rounded-xl text-xs">
              <button
                type="button"
                onClick={() => setFilterStops('all')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                  filterStops === 'all'
                    ? 'bg-blue-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All Stops
              </button>
              <button
                type="button"
                onClick={() => setFilterStops('direct')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                  filterStops === 'direct'
                    ? 'bg-blue-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Non-Stop
              </button>
            </div>

            {/* Sort selector */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-slate-50 border border-slate-300 text-xs text-slate-700 font-semibold rounded-xl px-3 py-2 focus:outline-none focus:border-blue-700 shadow-xs"
            >
              <option value="price">Lowest Fare</option>
              <option value="departure">Earliest Departure</option>
              <option value="duration">Shortest Duration</option>
            </select>
          </div>
        </div>

        {/* Active Filters Pill Bar (when filters applied) */}
        {(selectedAirlines.length > 0 || filterStops !== 'all') && (
          <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center gap-2 text-xs">
            <span className="text-slate-500 text-[11px] font-bold">Active filters:</span>
            {selectedAirlines.length > 0 && (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-900 border border-blue-200 text-[11px] font-medium">
                <span>Airlines ({selectedAirlines.length})</span>
                <button
                  type="button"
                  onClick={() => setSelectedAirlines([])}
                  className="hover:text-rose-700 ml-1 font-bold"
                >
                  ×
                </button>
              </span>
            )}
            {filterStops === 'direct' && (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-900 border border-blue-200 text-[11px] font-medium">
                <span>Non-Stop Only</span>
                <button
                  type="button"
                  onClick={() => setFilterStops('all')}
                  className="hover:text-rose-700 ml-1 font-bold"
                >
                  ×
                </button>
              </span>
            )}
            <button
              type="button"
              onClick={() => {
                setSelectedAirlines([]);
                setFilterStops('all');
              }}
              className="text-[11px] text-slate-500 hover:text-blue-900 font-bold ml-1 flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              Reset all
            </button>
          </div>
        )}
      </div>

      {/* Flight Cards List */}
      {filteredFlights.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-400 mx-auto">
            <Plane className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900">
              {selectedAirlines.length > 0
                ? 'No flights found for the selected airline'
                : 'No flights match your search criteria'}
            </h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
              {selectedAirlines.length > 0
                ? `None of our current schedules match the selected airline${
                    selectedAirlines.length > 1 ? 's' : ''
                  }. You can clear the airline filter to inspect all available schedules.`
                : 'Try adjusting your destination, cabin class, or date filters to find available schedules.'}
            </p>
          </div>

          <button
            type="button"
            onClick={() => {
              setSelectedAirlines([]);
              setFilterStops('all');
            }}
            className="px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl text-xs transition-colors shadow-xs"
          >
            Show All Available Flights
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredFlights.map((flight) => {
            const isSelected = selectedFlight?.id === flight.id;
            const depTime = new Date(flight.departureTime).toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
            });
            const arrTime = new Date(flight.arrivalTime).toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
            });
            const depDate = new Date(flight.departureTime).toLocaleDateString([], {
              month: 'short',
              day: 'numeric',
            });

            return (
              <div
                key={flight.id}
                className={`p-5 rounded-2xl border transition-all ${
                  isSelected
                    ? 'bg-blue-50/50 border-blue-600 ring-2 ring-blue-500/30 shadow-md'
                    : 'bg-white border-slate-200 hover:border-blue-300 shadow-xs'
                }`}
              >
                <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
                  {/* Flight Schedule */}
                  <div className="flex-1 w-full">
                    <div className="flex flex-wrap items-center gap-2.5 text-xs text-slate-500 mb-3">
                      <span className="font-bold text-blue-950 px-2 py-0.5 rounded-md bg-slate-100 border border-slate-200">
                        {flight.airline}
                      </span>
                      <span>•</span>
                      <span className="font-mono text-blue-800 font-bold">{flight.flightNumber}</span>
                      <span>•</span>
                      <span>{flight.aircraft}</span>
                      <span>•</span>
                      <span className="flex items-center gap-1 text-slate-600">
                        <Luggage className="w-3.5 h-3.5" />
                        Standard Baggage Included
                      </span>
                    </div>

                    <div className="grid grid-cols-3 items-center gap-4 max-w-xl">
                      {/* Origin */}
                      <div>
                        <div className="text-2xl font-black text-slate-900 tracking-tight">{depTime}</div>
                        <div className="text-base font-bold text-blue-900">{flight.origin.code}</div>
                        <div className="text-xs text-slate-600 truncate font-medium">{flight.origin.city}</div>
                        <div className="text-[11px] text-slate-400">{depDate} • T{flight.origin.terminal || '1'}</div>
                      </div>

                      {/* Duration / Stops */}
                      <div className="text-center">
                        <div className="text-xs text-slate-500 flex items-center justify-center gap-1">
                          <Clock className="w-3 h-3 text-slate-400" />
                          <span>{flight.duration}</span>
                        </div>
                        <div className="relative my-2">
                          <div className="h-0.5 bg-slate-200 w-full" />
                          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white px-2 text-blue-800">
                            <Plane className="w-3.5 h-3.5 transform rotate-90" />
                          </div>
                        </div>
                        <span className="text-[11px] font-bold text-emerald-700">
                          {flight.stops === 0 ? 'Non-Stop' : `${flight.stops} Stop`}
                        </span>
                      </div>

                      {/* Destination */}
                      <div className="text-right">
                        <div className="text-2xl font-black text-slate-900 tracking-tight">{arrTime}</div>
                        <div className="text-base font-bold text-blue-900">{flight.destination.code}</div>
                        <div className="text-xs text-slate-600 truncate font-medium">{flight.destination.city}</div>
                        <div className="text-[11px] text-slate-400">T{flight.destination.terminal || '2'}</div>
                      </div>
                    </div>
                  </div>

                  {/* Cabin Selection & Pricing Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 w-full lg:w-auto">
                    {cabinClasses.map(({ key, label }) => {
                      const priceUSD = flight.prices[key];
                      const availableSeats = flight.availableSeats[key] || 0;
                      const isSoldOut = availableSeats <= 0;
                      const isCabinActive = isSelected && selectedCabinClass === key;
                      const formatted = formatPrice(priceUSD);

                      return (
                        <button
                          key={key}
                          type="button"
                          disabled={isSoldOut}
                          onClick={() => onSelectFlight(flight, key)}
                          className={`p-3 rounded-xl border text-left transition-all min-w-[115px] relative ${
                            isSoldOut
                              ? 'bg-slate-100/60 border-slate-200 opacity-50 cursor-not-allowed'
                              : isCabinActive
                              ? 'bg-blue-900 text-white border-blue-950 shadow-md ring-1 ring-blue-500'
                              : 'bg-slate-50 border-slate-200 hover:border-blue-400 text-slate-800 hover:bg-white'
                          }`}
                        >
                          <div
                            className={`text-[10px] font-bold uppercase tracking-wider truncate ${
                              isCabinActive ? 'text-blue-200' : 'text-slate-500'
                            }`}
                          >
                            {label}
                          </div>

                          <div
                            className={`text-base font-extrabold mt-1 font-mono ${
                              isCabinActive ? 'text-white' : 'text-slate-900'
                            }`}
                          >
                            {formatted}
                          </div>

                          <div
                            className={`text-[10px] mt-0.5 ${
                              isCabinActive ? 'text-blue-200' : 'text-slate-400'
                            }`}
                          >
                            {isSoldOut ? (
                              <span className="text-rose-500 font-bold">Sold Out</span>
                            ) : availableSeats <= 5 ? (
                              <span className="text-amber-500 font-semibold">{availableSeats} seats left</span>
                            ) : currency.code !== 'USD' ? (
                              `($${priceUSD} USD)`
                            ) : (
                              '/ traveler'
                            )}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Continue CTA */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-200">
        <div>
          {selectedFlight ? (
            <p className="text-xs text-slate-600">
              Selected: <strong className="text-blue-950">{selectedFlight.flightNumber}</strong> ({selectedFlight.airline}) • {selectedCabinClass.toUpperCase()} Class
            </p>
          ) : (
            <p className="text-xs text-slate-500">Please choose a flight and cabin above to continue</p>
          )}
        </div>

        <button
          type="button"
          disabled={!selectedFlight}
          onClick={handleProceed}
          className="w-full sm:w-auto flex items-center justify-center gap-2 py-3 px-7 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-xs text-sm"
        >
          <span>{user ? 'Continue to Traveler Details' : 'Sign In & Continue to Book'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
