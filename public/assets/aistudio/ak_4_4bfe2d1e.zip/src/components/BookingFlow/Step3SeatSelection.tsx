import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, Check, User } from 'lucide-react';
import { useCurrency } from '../../context/CurrencyContext.tsx';
import type { CabinClass, Passenger } from '../../types/index.ts';

interface Step3Props {
  cabinClass: CabinClass;
  passengers: Passenger[];
  selectedSeats: Record<string, string>; // passengerId -> seatNumber
  onSelectSeat: (passengerId: string, seatNumber: string, fee: number) => void;
  onNext: () => void;
  onBack: () => void;
}

interface SeatDef {
  number: string;
  row: number;
  col: string;
  isExtraLegroom?: boolean;
  fee: number;
  type: 'window' | 'aisle' | 'standard';
  isOccupied: boolean;
}

export function Step3SeatSelection({
  cabinClass,
  passengers,
  selectedSeats,
  onSelectSeat,
  onNext,
  onBack,
}: Step3Props) {
  const { formatPrice } = useCurrency();
  const [activePaxIndex, setActivePaxIndex] = useState<number>(0);
  const currentPax = passengers[activePaxIndex] || passengers[0];

  // Generate aircraft seat rows based on cabin class
  const rows =
    cabinClass === 'first' || cabinClass === 'business'
      ? [1, 2, 3, 4]
      : cabinClass === 'premiumEconomy'
      ? [5, 6, 7, 8, 9]
      : [10, 11, 12, 14, 15, 16, 17, 18, 19, 20];

  const columns =
    cabinClass === 'first' || cabinClass === 'business'
      ? ['A', 'C', 'D', 'F']
      : ['A', 'B', 'C', 'D', 'E', 'F'];

  const occupiedSeats = new Set(['1A', '2D', '5B', '6C', '11A', '12F', '15C', '16D', '18B']);

  const getSeatDef = (row: number, col: string): SeatDef => {
    const number = `${row}${col}`;
    const isWindow = col === 'A' || col === 'F';
    const isAisle = col === 'C' || col === 'D';
    const isExtraLegroom = row === 1 || row === 5 || row === 10 || row === 14;
    const fee = isExtraLegroom ? 35 : isWindow || isAisle ? 15 : 0;
    return {
      number,
      row,
      col,
      isExtraLegroom,
      fee,
      type: isWindow ? 'window' : isAisle ? 'aisle' : 'standard',
      isOccupied: occupiedSeats.has(number),
    };
  };

  const handleSeatClick = (seat: SeatDef) => {
    if (seat.isOccupied) return;
    // Check if another passenger already chose this seat
    const alreadyChosenBy = Object.entries(selectedSeats).find(
      ([paxId, sNum]) => sNum === seat.number && paxId !== currentPax.id
    );
    if (alreadyChosenBy) return;

    onSelectSeat(currentPax.id, seat.number, seat.fee);

    // Automatically suggest next passenger if not all seated
    if (activePaxIndex < passengers.length - 1) {
      setActivePaxIndex(activePaxIndex + 1);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-xl bg-white border border-slate-200 shadow-xs">
        <div>
          <span className="text-xs font-bold text-blue-900 tracking-wider uppercase">Step 3 of 5</span>
          <h2 className="text-xl font-bold text-slate-900 mt-0.5">Select Aircraft Seats</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Choose your preferred seat on the interactive aircraft map for each traveler
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5">
            <div className="w-3.5 h-3.5 rounded bg-blue-900" />
            <span className="text-slate-800 font-semibold">Selected</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3.5 h-3.5 rounded bg-slate-50 border border-slate-300" />
            <span className="text-slate-600">Available</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3.5 h-3.5 rounded bg-slate-200 border border-slate-200 opacity-60" />
            <span className="text-slate-400">Occupied</span>
          </div>
        </div>
      </div>

      {/* Passenger Selector Tabs */}
      <div className="flex items-center gap-2 p-1.5 bg-white border border-slate-200 rounded-xl overflow-x-auto shadow-xs">
        {passengers.map((pax, idx) => {
          const seat = selectedSeats[pax.id];
          const isActive = idx === activePaxIndex;
          return (
            <button
              key={pax.id}
              type="button"
              onClick={() => setActivePaxIndex(idx)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                isActive ? 'bg-blue-900 text-white shadow-xs' : 'text-slate-700 hover:bg-slate-100'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>{pax.firstName || `Traveler #${idx + 1}`}</span>
              <span
                className={`px-1.5 py-0.5 rounded text-[10px] font-mono ${
                  isActive ? 'bg-blue-800 text-blue-100 font-bold' : 'bg-slate-100 text-slate-600'
                }`}
              >
                {seat ? `Seat ${seat}` : 'Select Seat'}
              </span>
            </button>
          );
        })}
      </div>

      {/* Aircraft Fuselage Layout */}
      <div className="max-w-2xl mx-auto p-6 sm:p-8 rounded-3xl bg-white border border-slate-200 shadow-sm relative">
        {/* Flight Deck graphic */}
        <div className="w-32 h-10 mx-auto -mt-4 mb-6 rounded-t-full bg-slate-100 border-t border-x border-slate-200 flex items-center justify-center">
          <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Flight Deck</span>
        </div>

        {/* Seat rows */}
        <div className="space-y-3">
          {rows.map((rowNum) => (
            <div key={rowNum} className="flex items-center justify-center gap-2 sm:gap-3">
              {/* Left group */}
              <div className="flex items-center gap-1.5 sm:gap-2">
                {columns.slice(0, columns.length / 2).map((col) => {
                  const seat = getSeatDef(rowNum, col);
                  const isCurrentPaxSeat = selectedSeats[currentPax.id] === seat.number;
                  const isTakenByOther = Object.values(selectedSeats).includes(seat.number) && !isCurrentPaxSeat;
                  const isClickable = !seat.isOccupied && !isTakenByOther;

                  return (
                    <button
                      key={seat.number}
                      type="button"
                      disabled={!isClickable}
                      onClick={() => handleSeatClick(seat)}
                      title={`Seat ${seat.number} (${seat.type}) - ${
                        seat.fee > 0 ? `+${formatPrice(seat.fee)}` : 'Standard Included'
                      }`}
                      className={`w-9 h-10 rounded-lg text-xs font-bold font-mono transition-all flex flex-col items-center justify-center border ${
                        isCurrentPaxSeat
                          ? 'bg-blue-900 text-white border-blue-950 ring-2 ring-blue-500/50 scale-105 shadow-sm'
                          : isTakenByOther
                          ? 'bg-blue-100 text-blue-900 border-blue-300 cursor-not-allowed opacity-90'
                          : seat.isOccupied
                          ? 'bg-slate-200 border-slate-200 text-slate-400 cursor-not-allowed opacity-60'
                          : 'bg-slate-50 hover:bg-blue-50 border-slate-300 text-slate-800 hover:border-blue-600'
                      }`}
                    >
                      <span>{seat.number}</span>
                      {seat.fee > 0 && !seat.isOccupied && (
                        <span className="text-[8px] font-sans opacity-80">+{formatPrice(seat.fee)}</span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Aisle */}
              <div className="w-8 sm:w-12 text-center text-[10px] text-slate-400 font-mono font-bold">
                {rowNum}
              </div>

              {/* Right group */}
              <div className="flex items-center gap-1.5 sm:gap-2">
                {columns.slice(columns.length / 2).map((col) => {
                  const seat = getSeatDef(rowNum, col);
                  const isCurrentPaxSeat = selectedSeats[currentPax.id] === seat.number;
                  const isTakenByOther = Object.values(selectedSeats).includes(seat.number) && !isCurrentPaxSeat;
                  const isClickable = !seat.isOccupied && !isTakenByOther;

                  return (
                    <button
                      key={seat.number}
                      type="button"
                      disabled={!isClickable}
                      onClick={() => handleSeatClick(seat)}
                      title={`Seat ${seat.number} (${seat.type}) - ${
                        seat.fee > 0 ? `+${formatPrice(seat.fee)}` : 'Standard Included'
                      }`}
                      className={`w-9 h-10 rounded-lg text-xs font-bold font-mono transition-all flex flex-col items-center justify-center border ${
                        isCurrentPaxSeat
                          ? 'bg-blue-900 text-white border-blue-950 ring-2 ring-blue-500/50 scale-105 shadow-sm'
                          : isTakenByOther
                          ? 'bg-blue-100 text-blue-900 border-blue-300 cursor-not-allowed opacity-90'
                          : seat.isOccupied
                          ? 'bg-slate-200 border-slate-200 text-slate-400 cursor-not-allowed opacity-60'
                          : 'bg-slate-50 hover:bg-blue-50 border-slate-300 text-slate-800 hover:border-blue-600'
                      }`}
                    >
                      <span>{seat.number}</span>
                      {seat.fee > 0 && !seat.isOccupied && (
                        <span className="text-[8px] font-sans opacity-80">+{formatPrice(seat.fee)}</span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between pt-4 border-t border-slate-200">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-2 py-3 px-5 border border-slate-300 hover:border-slate-400 text-slate-700 hover:text-slate-900 font-semibold rounded-xl transition-colors text-sm"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Traveler Details</span>
        </button>

        <button
          type="button"
          onClick={onNext}
          className="flex items-center gap-2 py-3 px-6 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl transition-colors shadow-xs text-sm"
        >
          <span>Continue to Booking Confirmation</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
