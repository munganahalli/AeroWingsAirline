import React, { useState } from 'react';
import {
  AlertCircle,
  ArrowRightLeft,
  Calendar,
  CheckCircle2,
  Search,
  ShieldCheck,
} from 'lucide-react';
import { AirportSearchSelector } from './Search/AirportSearchSelector.tsx';
import { CabinSelector } from './Search/CabinSelector.tsx';
import { TravelersSelector } from './Search/TravelersSelector.tsx';
import type { Airport, CabinClass, TravelerCounts } from '../types/index.ts';
import heroAircraftImg from '../assets/images/aerowings_hero_sky.jpg';

interface HeroSearchProps {
  airports?: Airport[];
  onSearch: (params: {
    origin: string;
    destination: string;
    cabinClass: CabinClass;
    travelers: number;
    travelerCounts: TravelerCounts;
    date: string;
  }) => void;
  initialValues?: {
    origin?: string;
    destination?: string;
    cabinClass?: CabinClass;
    travelerCounts?: TravelerCounts;
    date?: string;
  };
}

export function HeroSearch({ onSearch, initialValues }: HeroSearchProps) {
  const [origin, setOrigin] = useState<string>(initialValues?.origin || 'DEL');
  const [destination, setDestination] = useState<string>(initialValues?.destination || 'BOM');
  const [cabinClass, setCabinClass] = useState<CabinClass>(initialValues?.cabinClass || 'economy');
  const [travelerCounts, setTravelerCounts] = useState<TravelerCounts>(
    initialValues?.travelerCounts || { adults: 1, children: 0, infants: 0 }
  );
  const [validationError, setValidationError] = useState<string | null>(null);
  const [departureDate, setDepartureDate] = useState(() => {
    if (initialValues?.date) return initialValues.date;
    const d = new Date();
    d.setDate(d.getDate() + 2);
    return d.toISOString().split('T')[0];
  });

  const handleSwap = () => {
    if (!origin || !destination) return;
    const temp = origin;
    setOrigin(destination);
    setDestination(temp);
    setValidationError(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    if (!origin || !destination) {
      setValidationError('Please select both Origin and Destination airports.');
      return;
    }

    if (origin.toUpperCase() === destination.toUpperCase()) {
      setValidationError('Origin and destination airports cannot be identical. Please select different airports.');
      return;
    }

    const totalTravelers = travelerCounts.adults + travelerCounts.children + travelerCounts.infants;
    if (travelerCounts.adults < 1) {
      setValidationError('At least one adult passenger (12+) is required for booking.');
      return;
    }

    if (travelerCounts.infants > travelerCounts.adults) {
      setValidationError('Each infant must be accompanied by at least one adult.');
      return;
    }

    onSearch({
      origin,
      destination,
      cabinClass,
      travelers: totalTravelers,
      travelerCounts,
      date: departureDate,
    });
  };

  return (
    <div className="relative">
      {/* Hero Visual Section with preserved aircraft photo */}
      <div className="relative overflow-hidden rounded-3xl border border-slate-200 bg-blue-950 shadow-lg min-h-[360px] flex items-center">
        {/* Background aircraft photo with measured airline gradient */}
        <div className="absolute inset-0 z-0 overflow-hidden">
          <img
            src={heroAircraftImg}
            alt="AeroWings airliner cruising above clouds"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).src = '/assets/images/aerowings_hero_sky.jpg';
            }}
            className="w-full h-full object-cover object-[center_35%] opacity-90 sm:opacity-95 transform scale-105 transition-transform duration-700 hover:scale-100"
          />
          {/* Measured dual-layer scrim: preserves aircraft visibility while ensuring high-contrast text */}
          <div className="absolute inset-0 bg-gradient-to-t from-blue-950/92 via-blue-950/45 to-blue-950/20" />
          <div className="absolute inset-0 bg-gradient-to-r from-blue-950/60 via-transparent to-blue-950/60" />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 max-w-4xl mx-auto px-6 py-10 sm:py-14 text-center space-y-3.5">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-white/90 border border-blue-200 text-xs font-bold text-blue-950 shadow-xs backdrop-blur-xs">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-700" />
            <span>Official AeroWings Flight Reservations • Verified OTP & E-Tickets</span>
          </div>

          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight leading-tight">
            Fly AeroWings • Elevate Your Journey
          </h1>

          <p className="text-sm sm:text-base text-blue-100 max-w-2xl mx-auto leading-relaxed">
            Reserve your domestic & international flights with 5-step precision. Search 204 verified airports, filter 100 global airlines, and download official electronic PDF tickets.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-5 pt-1 text-xs text-blue-100">
            <span className="flex items-center gap-1.5 font-medium">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              95 Indian Domestic & 109 Int'l Hubs
            </span>
            <span className="flex items-center gap-1.5 font-medium">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              100 Filterable Airlines
            </span>
            <span className="flex items-center gap-1.5 font-medium">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              Multi-Currency & Verified OTP
            </span>
          </div>
        </div>
      </div>

      {/* Flight Search Strip Floating Card */}
      <div className="relative z-20 -mt-10 max-w-5xl mx-auto px-4 sm:px-6">
        <form
          onSubmit={handleSubmit}
          className="p-5 sm:p-6 rounded-2xl bg-white border border-slate-200 shadow-xl space-y-4"
        >
          {validationError && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs animate-in fade-in">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
              <span>{validationError}</span>
            </div>
          )}

          {/* Top Options Bar: Cabin Class & Travelers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pb-1">
            <CabinSelector
              value={cabinClass}
              onChange={(c) => setCabinClass(c)}
              label="Cabin Class"
            />
            <TravelersSelector
              value={travelerCounts}
              onChange={(t) => setTravelerCounts(t)}
            />
          </div>

          {/* Search Inputs Row with Origin, Swap, Destination, Date & Search CTA */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-3 items-end">
            {/* From (Origin) */}
            <div className="lg:col-span-4">
              <AirportSearchSelector
                label="From (Origin)"
                value={origin}
                onChange={(code) => {
                  setOrigin(code);
                  setValidationError(null);
                }}
                disabledAirportCode={destination}
                placeholder="Select origin airport..."
                iconColor="text-blue-900"
              />
            </div>

            {/* Swap Button */}
            <div className="flex lg:col-span-1 justify-center pb-0.5">
              <button
                type="button"
                onClick={handleSwap}
                className="w-full sm:w-auto p-2.5 rounded-xl bg-slate-100 hover:bg-blue-50 border border-slate-300 hover:border-blue-300 text-slate-700 hover:text-blue-900 transition-colors shadow-xs flex items-center justify-center gap-1.5"
                title="Swap Origin & Destination"
                aria-label="Swap Origin & Destination"
              >
                <ArrowRightLeft className="w-4 h-4" />
                <span className="lg:hidden text-xs font-bold">Swap</span>
              </button>
            </div>

            {/* To (Destination) */}
            <div className="lg:col-span-4">
              <AirportSearchSelector
                label="To (Destination)"
                value={destination}
                onChange={(code) => {
                  setDestination(code);
                  setValidationError(null);
                }}
                disabledAirportCode={origin}
                placeholder="Select destination airport..."
                iconColor="text-emerald-700"
              />
            </div>

            {/* Departure Date */}
            <div className="lg:col-span-3">
              <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1 tracking-wide">
                Departure Date
              </label>
              <div className="relative">
                <Calendar className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
                <input
                  type="date"
                  value={departureDate}
                  min={new Date().toISOString().split('T')[0]}
                  onChange={(e) => setDepartureDate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-10 pr-3 py-2.5 text-xs font-semibold text-slate-900 focus:outline-none focus:border-blue-700 focus:bg-white"
                />
              </div>
            </div>
          </div>

          {/* Submit Action Bar */}
          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              className="w-full sm:w-auto py-3 px-8 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl transition-colors flex items-center justify-center gap-2 shadow-xs text-sm"
            >
              <Search className="w-4 h-4" />
              <span>Search Flights</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
