import express, { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import {
  AIRPORTS,
  bookingsStore,
  emailLogsStore,
  flightsStore,
  generatePnr,
  generateSecureVerificationToken,
  hashPassword,
  otpStore,
  saveStoreToDisk,
  usersStore,
  validateStrongPassword,
} from './db.ts';
import {
  isResendTestRecipient,
  parseResendError,
  renderBookingConfirmationEmailHtml,
  renderCancellationEmailHtml,
  renderOtpEmailHtml,
  sendBookingConfirmationEmail,
  sendCancellationEmail,
  sendOtpEmail,
} from './emailService.ts';
import type { Booking, CabinClass, Flight, Passenger, PassengerBaggageSelection } from './types.ts';
import { fetchLiveExchangeRates } from './exchangeRates.ts';
import { getAirportWeather } from './weatherService.ts';
import {
  getAllBaggagePolicies,
  getAdditionalBaggageOptions,
  getBaggageAllowance,
  updateBaggagePolicies,
} from './baggageService.ts';
import { broadcastLiveEvent, registerLiveClient } from './liveEvents.ts';

export const apiRouter = express.Router();

// -------------------------------------------------------------
// DEFENSE-IN-DEPTH MIDDLEWARE: GUARANTEE req.query & req.body
// -------------------------------------------------------------
apiRouter.use((req: any, res: any, next: NextFunction) => {
  if (!req.query) {
    req.query = {};
  }
  if (req.url && req.url.includes('?')) {
    try {
      const parsedUrl = new URL(req.url, 'http://localhost');
      parsedUrl.searchParams.forEach((val, key) => {
        if (req.query[key] === undefined) {
          req.query[key] = val;
        }
      });
    } catch {
      // Ignore URL parsing fallback
    }
  }
  if (!res.json) {
    res.json = function (data: any) {
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify(data));
      return res;
    };
  }
  if (!res.status) {
    res.status = function (statusCode: number) {
      res.statusCode = statusCode;
      return res;
    };
  }
  next();
});

apiRouter.use(express.json());

// -------------------------------------------------------------
// SYSTEM CONFIGURATION / HEALTH CHECK & DEV TEST MODE INFO
// -------------------------------------------------------------
apiRouter.get('/config', (req: Request, res: Response) => {
  const hasResendKey = Boolean(
    process.env.RESEND_API_KEY &&
    !process.env.RESEND_API_KEY.includes('1234567890abcdef') &&
    process.env.RESEND_API_KEY.startsWith('re_')
  );
  const appUrl = process.env.APP_URL?.trim() || `${req.protocol}://${req.get('host')}`;

  res.json({
    appName: 'AeroWings Airline Flight Booking & Management System',
    appUrl,
    resendConfigured: hasResendKey,
    resendFromEmail: process.env.RESEND_FROM_EMAIL || 'AeroWings <onboarding@resend.dev>',
    authMode: 'EMAIL_OTP_ONLY',
    smsEnabled: false,
    devTestMode: {
      enabled: true,
      freeTestingFeatures: [
        'Safe Development OTP generation & 5-minute expiry testing',
        'Single-use code consumption and 60-second cooldown verification',
        'Live email template preview and responsive HTML inspection',
        'Automatic customer recipient validation (Registration vs Database Account vs Booking Record)',
        'Resend official sandbox test addresses (delivered@resend.dev, bounced@resend.dev)',
        'Electronic ticket PDF download with verifiable QR code',
      ],
      customDomainRequirement:
        'Live email dispatch to arbitrary customer inboxes requires adding and verifying your domain in Resend (DNS records) with a custom RESEND_FROM_EMAIL.',
      resendTestRecipients: [
        { email: 'delivered@resend.dev', description: 'Simulates successful Resend delivery outcome' },
        { email: 'bounced@resend.dev', description: 'Simulates hard bounce rejection outcome' },
        { email: 'complained@resend.dev', description: 'Simulates spam complaint feedback loop' },
      ],
    },
  });
});

// -------------------------------------------------------------
// AIRPORTS & FLIGHT SEARCH WITH STRICT VALIDATION
// -------------------------------------------------------------
apiRouter.get('/airports', (_req: Request, res: Response) => {
  res.json(AIRPORTS);
});

apiRouter.get('/flights', (req: Request, res: Response) => {
  const query = req.query || {};
  const { origin, destination, cabinClass, date, passengers, airline, airlines } = query as Record<
    string,
    string | undefined
  >;

  // VALIDATION 1: Origin format
  if (origin !== undefined && origin !== '') {
    if (typeof origin !== 'string' || origin.trim().length < 2) {
      res.status(400).json({
        error: 'Invalid origin parameter. Must be a valid airport code or city name with at least 2 characters.',
        field: 'origin',
      });
      return;
    }
  }

  // VALIDATION 2: Destination format
  if (destination !== undefined && destination !== '') {
    if (typeof destination !== 'string' || destination.trim().length < 2) {
      res.status(400).json({
        error: 'Invalid destination parameter. Must be a valid airport code or city name with at least 2 characters.',
        field: 'destination',
      });
      return;
    }
  }

  // VALIDATION 3: Origin and destination cannot be identical
  if (origin && destination) {
    if (origin.trim().toLowerCase() === destination.trim().toLowerCase()) {
      res.status(400).json({
        error: 'Origin and destination airports cannot be identical.',
        field: 'destination',
      });
      return;
    }
  }

  // VALIDATION 4: Cabin class validation
  const validCabins: CabinClass[] = ['economy', 'premiumEconomy', 'business', 'first'];
  if (cabinClass !== undefined && cabinClass !== '') {
    if (!validCabins.includes(cabinClass as CabinClass)) {
      res.status(400).json({
        error: `Invalid cabin class "${cabinClass}". Allowed options are: ${validCabins.join(', ')}.`,
        field: 'cabinClass',
      });
      return;
    }
  }

  // VALIDATION 5: Passenger count validation
  let paxCount = 1;
  if (passengers !== undefined && passengers !== '') {
    const parsedPax = Number(passengers);
    if (isNaN(parsedPax) || !Number.isInteger(parsedPax) || parsedPax < 1 || parsedPax > 9) {
      res.status(400).json({
        error: 'Invalid passenger count. Must be a whole integer between 1 and 9.',
        field: 'passengers',
      });
      return;
    }
    paxCount = parsedPax;
  }

  // VALIDATION 6: Departure date validation
  if (date !== undefined && date !== '') {
    const parsedDate = new Date(date);
    if (isNaN(parsedDate.getTime())) {
      res.status(400).json({
        error: 'Invalid departure date format. Please provide a valid date string (e.g. YYYY-MM-DD).',
        field: 'date',
      });
      return;
    }
  }

  // FILTERING LOGIC
  let results = [...flightsStore];

  // Origin filter
  if (origin && origin.trim()) {
    const cleanOrigin = origin.trim().toLowerCase();
    results = results.filter(
      (f) =>
        f.origin.code.toLowerCase() === cleanOrigin ||
        f.origin.city.toLowerCase() === cleanOrigin ||
        f.origin.name.toLowerCase().includes(cleanOrigin)
    );
  }

  // Destination filter
  if (destination && destination.trim()) {
    const cleanDest = destination.trim().toLowerCase();
    results = results.filter(
      (f) =>
        f.destination.code.toLowerCase() === cleanDest ||
        f.destination.city.toLowerCase() === cleanDest ||
        f.destination.name.toLowerCase().includes(cleanDest)
    );
  }

  // Airline filter (single or comma-separated list of airlines)
  const airlineParam = airlines || airline;
  if (airlineParam && typeof airlineParam === 'string' && airlineParam.trim()) {
    const airlineList = airlineParam
      .split(',')
      .map((a) => a.trim().toLowerCase())
      .filter(Boolean);
    if (airlineList.length > 0) {
      results = results.filter((f) => airlineList.includes(f.airline.toLowerCase()));
    }
  }

  // Cabin Class availability filter
  if (cabinClass && validCabins.includes(cabinClass as CabinClass)) {
    const cClass = cabinClass as CabinClass;
    results = results.filter((f) => (f.availableSeats[cClass] || 0) >= paxCount);
  }

  res.json(results);
});

apiRouter.get('/flights/:id', (req: Request, res: Response) => {
  const flight = flightsStore.find((f) => f.id === req.params.id);
  if (!flight) {
    res.status(404).json({ error: 'Flight not found' });
    return;
  }
  res.json(flight);
});

// -------------------------------------------------------------
// EMAIL OTP MANAGEMENT (5-min expiry, 60s cooldown, max 5 attempts)
// Requirement 4: Sends exclusively to each customer's own entered email!
// -------------------------------------------------------------
apiRouter.post('/auth/send-otp', async (req: Request, res: Response) => {
  const body = req.body || {};
  const { email, purpose } = body;

  if (!email || typeof email !== 'string' || !email.includes('@') || !email.includes('.')) {
    res.status(400).json({ error: 'A valid email address is required.' });
    return;
  }

  const cleanEmail = email.trim().toLowerCase();
  const validPurposes = ['REGISTRATION', 'LOGIN', 'PASSWORD_RESET', 'BOOKING_VERIFY'];
  const otpPurpose = validPurposes.includes(purpose) ? purpose : 'BOOKING_VERIFY';

  let targetEmail = cleanEmail;

  // Requirement 2: Password-reset emails target the correct account email stored in the database
  if (otpPurpose === 'PASSWORD_RESET') {
    const user = usersStore.find((u) => u.email.toLowerCase() === cleanEmail);
    if (!user) {
      // Return safe message without exposing user enumeration
      res.json({
        success: true,
        message: 'If an account matches this email, a verification code has been dispatched.',
        status: 'SIMULATED',
      });
      return;
    }
    targetEmail = user.email.toLowerCase();
  }

  // Check rate limit: 60s cooldown
  const existing = otpStore.get(targetEmail);
  const now = Date.now();
  if (existing && existing.purpose === otpPurpose && now - existing.lastSentAt < 60000) {
    const remainingSecs = Math.ceil((60000 - (now - existing.lastSentAt)) / 1000);
    res.status(429).json({
      error: `Please wait ${remainingSecs} seconds before requesting another verification code.`,
      retryAfter: remainingSecs,
    });
    return;
  }

  // Generate cryptographically unpredictable 6-digit OTP
  const code = (100000 + crypto.randomInt(900000)).toString();
  const expiresAt = now + 5 * 60 * 1000; // 5 minutes

  otpStore.set(targetEmail, {
    email: targetEmail,
    code,
    purpose: otpPurpose as any,
    createdAt: now,
    expiresAt,
    attempts: 0,
    verified: false,
    lastSentAt: now,
  });

  const sendResult = await sendOtpEmail(targetEmail, code, otpPurpose as any);

  if (sendResult.status === 'FAILED') {
    res.status(sendResult.isDomainRestriction ? 422 : 502).json({
      error: sendResult.error || 'Resend rejected the request. Verification code could not be delivered.',
      status: 'FAILED',
      isDomainRestriction: sendResult.isDomainRestriction,
      guidance: sendResult.guidance,
    });
    return;
  }

  res.json({
    success: true,
    message: `Verification code dispatched to ${targetEmail}. Valid for 5 minutes.`,
    status: sendResult.status,
    resendId: sendResult.resendId,
    cooldownSeconds: 60,
    expiresInSeconds: 300,
    simulatedCode: sendResult.simulatedCode,
  });
});

apiRouter.post('/auth/verify-otp', (req: Request, res: Response) => {
  const body = req.body || {};
  const { email, code, purpose } = body;

  if (!email || !code) {
    res.status(400).json({ error: 'Email and 6-digit verification code are required.' });
    return;
  }

  const cleanEmail = email.trim().toLowerCase();
  const cleanCode = code.toString().trim();
  const record = otpStore.get(cleanEmail);
  const now = Date.now();

  if (!record || (purpose && record.purpose !== purpose)) {
    res.status(400).json({ error: 'No active verification code found for this email. Please request a new code.' });
    return;
  }

  if (now > record.expiresAt) {
    otpStore.delete(cleanEmail);
    res.status(400).json({ error: 'Verification code has expired (valid 5 minutes). Please request a new code.' });
    return;
  }

  if (record.attempts >= 5) {
    otpStore.delete(cleanEmail);
    res.status(400).json({ error: 'Maximum verification attempts exceeded. Code has been invalidated. Please request a new code.' });
    return;
  }

  if (record.code !== cleanCode) {
    record.attempts += 1;
    const remaining = 5 - record.attempts;
    res.status(400).json({
      error: `Invalid verification code. ${remaining} attempt${remaining === 1 ? '' : 's'} remaining.`,
      remainingAttempts: remaining,
    });
    return;
  }

  // Verification successful! Single-use flag set.
  record.verified = true;
  res.json({
    verified: true,
    message: 'Email successfully verified.',
  });
});

// -------------------------------------------------------------
// USER REGISTRATION & AUTHENTICATION (Persistent database, secure hash)
// -------------------------------------------------------------
apiRouter.post('/auth/register', (req: Request, res: Response) => {
  const body = req.body || {};
  const { name, email, password } = body;

  if (!name || typeof name !== 'string' || name.trim().length < 2) {
    res.status(400).json({ error: 'Please enter your full legal name.' });
    return;
  }

  if (!email || !email.includes('@')) {
    res.status(400).json({ error: 'A valid email address is required.' });
    return;
  }

  const cleanEmail = email.trim().toLowerCase();

  // Enforce strong password rules
  const passwordCheck = validateStrongPassword(password);
  if (!passwordCheck.valid) {
    res.status(400).json({ error: passwordCheck.message });
    return;
  }

  // Check email verification status
  const otpRecord = otpStore.get(cleanEmail);
  if (!otpRecord || !otpRecord.verified || otpRecord.purpose !== 'REGISTRATION') {
    res.status(400).json({ error: 'Email verification is required before completing registration. Please verify your OTP.' });
    return;
  }

  // Check if user already exists
  if (usersStore.some((u) => u.email.toLowerCase() === cleanEmail)) {
    res.status(400).json({ error: 'An account with this email address already exists. Please sign in.' });
    return;
  }

  const newUser = {
    id: 'usr_' + Math.random().toString(36).substring(2, 10),
    name: name.trim(),
    email: cleanEmail,
    passwordHash: hashPassword(password),
    role: 'customer' as const,
    createdAt: new Date().toISOString(),
  };

  usersStore.push(newUser);
  saveStoreToDisk(); // Persist to database file immediately!
  otpStore.delete(cleanEmail); // Clear single-use OTP

  res.status(201).json({
    success: true,
    user: {
      id: newUser.id,
      name: newUser.name,
      email: newUser.email,
      role: newUser.role,
    },
  });
});

apiRouter.post('/auth/login', (req: Request, res: Response) => {
  const body = req.body || {};
  const { email, password } = body;

  if (!email || !password) {
    res.status(400).json({ error: 'Email and password are required.' });
    return;
  }

  const cleanEmail = email.trim().toLowerCase();
  const inputHash = hashPassword(password);

  const user = usersStore.find((u) => u.email.toLowerCase() === cleanEmail);

  if (!user || user.passwordHash !== inputHash) {
    res.status(401).json({ error: 'Invalid email or password.' });
    return;
  }

  res.json({
    success: true,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
    },
  });
});

// PASSWORD RESET WITH EMAIL OTP
apiRouter.post('/auth/forgot-password/request', async (req: Request, res: Response) => {
  const body = req.body || {};
  const { email } = body;

  if (!email || !email.includes('@')) {
    res.status(400).json({ error: 'Please enter a valid email address.' });
    return;
  }

  const cleanEmail = email.trim().toLowerCase();
  const user = usersStore.find((u) => u.email.toLowerCase() === cleanEmail);

  if (!user) {
    // Avoid user enumeration by returning a generic success message
    res.json({
      success: true,
      message: 'If an account matches this email, a verification code has been dispatched.',
    });
    return;
  }

  const code = (100000 + crypto.randomInt(900000)).toString();
  const now = Date.now();

  otpStore.set(cleanEmail, {
    email: cleanEmail,
    code,
    purpose: 'PASSWORD_RESET',
    createdAt: now,
    expiresAt: now + 5 * 60 * 1000,
    attempts: 0,
    verified: false,
    lastSentAt: now,
  });

  const sendResult = await sendOtpEmail(cleanEmail, code, 'PASSWORD_RESET');

  if (sendResult.status === 'FAILED') {
    res.status(sendResult.isDomainRestriction ? 422 : 502).json({
      error: sendResult.error || 'Resend rejected the request. Password reset code could not be delivered.',
      status: 'FAILED',
      isDomainRestriction: sendResult.isDomainRestriction,
      guidance: sendResult.guidance,
    });
    return;
  }

  res.json({
    success: true,
    message: `Password reset verification code sent to ${cleanEmail}. Valid for 5 minutes.`,
    status: sendResult.status,
    simulatedCode: sendResult.simulatedCode,
  });
});

apiRouter.post('/auth/forgot-password/reset', (req: Request, res: Response) => {
  const body = req.body || {};
  const { email, newPassword } = body;

  if (!email || !newPassword) {
    res.status(400).json({ error: 'Email and new password are required.' });
    return;
  }

  const cleanEmail = email.trim().toLowerCase();
  const otpRecord = otpStore.get(cleanEmail);

  if (!otpRecord || !otpRecord.verified || otpRecord.purpose !== 'PASSWORD_RESET') {
    res.status(400).json({ error: 'Email OTP verification is required before resetting your password.' });
    return;
  }

  const passwordCheck = validateStrongPassword(newPassword);
  if (!passwordCheck.valid) {
    res.status(400).json({ error: passwordCheck.message });
    return;
  }

  const user = usersStore.find((u) => u.email.toLowerCase() === cleanEmail);
  if (!user) {
    res.status(404).json({ error: 'User account not found.' });
    return;
  }

  user.passwordHash = hashPassword(newPassword);
  saveStoreToDisk();
  otpStore.delete(cleanEmail);

  res.json({
    success: true,
    message: 'Your password has been reset successfully. Please sign in with your new password.',
  });
});

// -------------------------------------------------------------
// BOOKING CREATION & CONFIRMATION (Step 5 Pay & Verify OTP)
// -------------------------------------------------------------
apiRouter.post('/bookings/create', async (req: Request, res: Response) => {
  const body = req.body || {};
  const {
    flightId,
    cabinClass,
    passengers,
    contactEmail,
    contactPhone,
    fareBreakdown,
    paymentMethod,
    idempotencyKey,
  } = body;

  // 1. REQUIRE AUTHENTICATION ON BACKEND BOOKING API (Requirement 1)
  const headerUserId = req.headers['x-user-id'] as string | undefined;
  const bodyUserId = req.body?.userId as string | undefined;
  const authHeader = req.headers.authorization;
  let callerUserId = headerUserId || bodyUserId;
  if (!callerUserId && authHeader && authHeader.startsWith('Bearer ')) {
    callerUserId = authHeader.substring(7).trim();
  }

  const authenticatedUser = callerUserId
    ? usersStore.find((u) => u.id === callerUserId || u.email.toLowerCase() === callerUserId.toLowerCase())
    : undefined;

  if (!authenticatedUser) {
    res.status(401).json({
      error: 'Authentication required. You must sign up or sign in before booking a flight.',
      code: 'UNAUTHENTICATED',
    });
    return;
  }

  // Validation
  if (!flightId || !cabinClass || !passengers || !Array.isArray(passengers) || passengers.length === 0) {
    res.status(400).json({ error: 'Invalid booking data: missing flight or passenger details.' });
    return;
  }

  if (!contactEmail || !contactEmail.includes('@')) {
    res.status(400).json({ error: 'Valid customer email is required for booking confirmation.' });
    return;
  }

  const cleanEmail = contactEmail.trim().toLowerCase();

  // Validate OTP was verified for booking
  const otpRecord = otpStore.get(cleanEmail);
  if (!otpRecord || !otpRecord.verified) {
    res.status(400).json({
      error: 'Email verification required. Please verify the 6-digit OTP sent to your email before confirming.',
    });
    return;
  }

  // Idempotency check to prevent duplicate bookings and duplicate emails
  if (idempotencyKey) {
    const existing = bookingsStore.find((b) => b.id === idempotencyKey);
    if (existing) {
      res.json({ success: true, booking: existing, isDuplicate: true });
      return;
    }
  }

  const flight = flightsStore.find((f) => f.id === flightId);
  if (!flight) {
    res.status(404).json({ error: 'Selected flight is no longer available.' });
    return;
  }

  // Check cabin seat inventory & reserve seats
  const cClass = cabinClass as CabinClass;
  if ((flight.availableSeats[cClass] || 0) < passengers.length) {
    res.status(400).json({
      error: `Insufficient seat availability in ${cabinClass} class. Only ${flight.availableSeats[cClass] || 0} seats remaining.`,
    });
    return;
  }
  flight.availableSeats[cClass] = Math.max(0, (flight.availableSeats[cClass] || 0) - passengers.length);

  // Calculate baggage fees and summary from passengers
  let calculatedBaggageFee = 0;
  const addons: { passengerName: string; optionTitle: string; feeUSD: number }[] = [];
  passengers.forEach((p: any) => {
    if (p.baggage?.extraFeeUSD && p.baggage.extraFeeUSD > 0) {
      calculatedBaggageFee += Number(p.baggage.extraFeeUSD);
      addons.push({
        passengerName: `${p.title || ''} ${p.firstName || ''} ${p.lastName || ''}`.trim() || 'Passenger',
        optionTitle: p.baggage.extraOptionTitle || 'Additional Baggage',
        feeUSD: Number(p.baggage.extraFeeUSD),
      });
    }
  });

  const baseFare = Number(fareBreakdown?.baseFare || 500);
  const taxesAndFees = Number(fareBreakdown?.taxesAndFees || 60);
  const seatSelectionFee = Number(fareBreakdown?.seatSelectionFee || 0);
  const baggageFee = Number(fareBreakdown?.baggageFee !== undefined ? fareBreakdown.baggageFee : calculatedBaggageFee);
  const totalAmount = Number((baseFare + taxesAndFees + seatSelectionFee + baggageFee).toFixed(2));

  const pnr = generatePnr();
  const verificationToken = generateSecureVerificationToken();
  const nowIso = new Date().toISOString();

  const isDomesticRoute =
    flight.origin.country?.toLowerCase() === 'india' && flight.destination.country?.toLowerCase() === 'india';
  const defaultCabinText =
    cClass === 'first' ? '2 Cabin Bags (18 kg) + Personal Item' :
    cClass === 'business' ? '2 Cabin Bags (14 kg) + Personal Item' :
    cClass === 'premiumEconomy' ? '1 Cabin Bag (10 kg) + Personal Item' :
    '1 Cabin Bag (7 kg) + Personal Item';
  const defaultCheckedText =
    isDomesticRoute
      ? (cClass === 'business' ? '35 kg Included' : cClass === 'premiumEconomy' ? '25 kg Included' : '15 kg Included')
      : (cClass === 'first' ? '3x 32 kg (96 kg total) Included' : cClass === 'business' ? '2x 32 kg (64 kg total) Included' : cClass === 'premiumEconomy' ? '2x 23 kg (46 kg total) Included' : '23 kg Included');

  const newBooking: Booking = {
    id: idempotencyKey || 'bkg_' + Math.random().toString(36).substring(2, 10),
    userId: authenticatedUser.id,
    customerName: authenticatedUser.name,
    pnr,
    verificationToken,
    flightId,
    flight,
    cabinClass,
    passengers,
    contactEmail: cleanEmail,
    contactPhone: contactPhone || '',
    fareBreakdown: {
      baseFare,
      taxesAndFees,
      seatSelectionFee,
      baggageFee,
      totalAmount,
      currency: 'USD',
    },
    originalCurrency: 'USD',
    originalAmount: totalAmount,
    baggageDetails: body.baggageSummary || {
      cabinAllowanceSummary: defaultCabinText,
      checkedAllowanceSummary: defaultCheckedText,
      totalBaggageFeeUSD: baggageFee,
      selectedAddons: addons,
    },
    paymentStatus: 'PAID',
    paymentMethod: paymentMethod || 'AeroPay Secure Card',
    paymentTransactionId: 'tx_aerowings_' + Math.random().toString(36).substring(2, 12),
    bookingStatus: 'CONFIRMED',
    createdAt: nowIso,
    confirmedAt: nowIso,
    emailConfirmationSent: false,
    emailDeliveryStatus: 'PENDING',
    ticketGenerated: true,
  };

  // Save to database and persist immediately
  bookingsStore.unshift(newBooking);
  saveStoreToDisk();

  // Invalidate single-use OTP
  otpStore.delete(cleanEmail);

  // Broadcast real-time live booking creation to all connected admin dashboards
  broadcastLiveEvent('BOOKING_CREATED', {
    pnr: newBooking.pnr,
    id: newBooking.id,
    customerEmail: newBooking.contactEmail,
    customerName: newBooking.customerName,
    flightNumber: newBooking.flight.flightNumber,
    totalAmount: newBooking.fareBreakdown.totalAmount,
    createdAt: newBooking.createdAt,
  }, `New booking #${newBooking.pnr} confirmed and saved to database`);

  // AUTOMATICALLY SEND BOOKING CONFIRMATION EMAIL VIA RESEND DIRECTLY TO THIS CUSTOMER
  const appBaseUrl = process.env.APP_URL?.trim() || `${req.protocol}://${req.get('host')}`;
  try {
    const emailResult = await sendBookingConfirmationEmail(newBooking, appBaseUrl);
    if (emailResult.status === 'SENT') {
      newBooking.emailConfirmationSent = true;
      newBooking.emailDeliveryStatus = 'DELIVERED';
      newBooking.emailConfirmationId = emailResult.resendId;
    } else if (emailResult.status === 'SIMULATED') {
      newBooking.emailConfirmationSent = true;
      newBooking.emailDeliveryStatus = 'SIMULATED';
    } else {
      newBooking.emailConfirmationSent = false;
      newBooking.emailDeliveryStatus = 'FAILED';
      newBooking.emailDeliveryError = emailResult.error || 'Failed to dispatch via Resend';
    }
  } catch (err: any) {
    newBooking.emailConfirmationSent = false;
    newBooking.emailDeliveryStatus = 'FAILED';
    newBooking.emailDeliveryError = err.message;
  }

  saveStoreToDisk();

  res.status(201).json({
    success: true,
    booking: newBooking,
  });
});

// GET USER'S BOOKINGS OR LOOKUP BY PNR & EMAIL / USER ID
apiRouter.get('/bookings/my', (req: Request, res: Response) => {
  const query = req.query || {};
  const { email, pnr, userId } = query as Record<string, string | undefined>;
  const headerUserId = req.headers['x-user-id'] as string | undefined;
  const authHeader = req.headers.authorization;
  const effectiveUserId =
    userId || headerUserId || (authHeader?.startsWith('Bearer ') ? authHeader.slice(7).trim() : undefined);

  let results = [...bookingsStore];

  if (effectiveUserId) {
    results = results.filter(
      (b) =>
        b.userId === effectiveUserId ||
        (email && b.contactEmail.toLowerCase() === email.trim().toLowerCase())
    );
  } else if (email && typeof email === 'string' && email.trim()) {
    results = results.filter((b) => b.contactEmail.toLowerCase() === email.trim().toLowerCase());
  }

  if (pnr && typeof pnr === 'string' && pnr.trim()) {
    results = results.filter((b) => b.pnr.toUpperCase() === pnr.trim().toUpperCase());
  }

  res.json(results);
});

// PUBLIC TICKET VERIFICATION (RESOLVED FROM QR CODE URL)
// URL format: /booking/verify/:token
// Never exposes passwords, OTPs, or payment credentials
apiRouter.get('/bookings/verify/:token', (req: Request, res: Response) => {
  const { token } = req.params;
  const booking = bookingsStore.find((b) => b.verificationToken === token);

  if (!booking) {
    res.status(404).json({
      verified: false,
      error: 'Invalid or expired ticket verification token. This ticket could not be validated.',
    });
    return;
  }

  // Safe public view for airline verification
  res.json({
    verified: true,
    pnr: booking.pnr,
    bookingStatus: booking.bookingStatus,
    airline: booking.flight.airline,
    flightNumber: booking.flight.flightNumber,
    aircraft: booking.flight.aircraft,
    origin: {
      code: booking.flight.origin.code,
      name: booking.flight.origin.name,
      city: booking.flight.origin.city,
      terminal: booking.flight.origin.terminal,
    },
    destination: {
      code: booking.flight.destination.code,
      name: booking.flight.destination.name,
      city: booking.flight.destination.city,
      terminal: booking.flight.destination.terminal,
    },
    departureTime: booking.flight.departureTime,
    arrivalTime: booking.flight.arrivalTime,
    cabinClass: booking.cabinClass,
    passengerCount: booking.passengers.length,
    passengerInitials: booking.passengers.map((p) => `${p.title} ${p.firstName[0]}. ${p.lastName}`),
    seats: booking.passengers.map((p) => p.seatNumber || 'Unassigned'),
    gate: booking.flight.gate || 'TBD',
    confirmedAt: booking.confirmedAt,
  });
});

// CANCEL BOOKING
apiRouter.post('/bookings/:id/cancel', async (req: Request, res: Response) => {
  const { id } = req.params;
  const body = req.body || {};
  const { reason } = body;

  const booking = bookingsStore.find((b) => b.id === id);
  if (!booking) {
    res.status(404).json({ error: 'Booking not found.' });
    return;
  }

  if (booking.bookingStatus === 'CANCELLED') {
    res.status(400).json({ error: 'Booking has already been cancelled.' });
    return;
  }

  booking.bookingStatus = 'CANCELLED';
  booking.cancelledAt = new Date().toISOString();
  booking.cancellationReason = reason || 'Customer requested online cancellation';
  booking.refundAmount = Number((booking.fareBreakdown.totalAmount * 0.9).toFixed(2));
  booking.paymentStatus = 'REFUNDED';

  saveStoreToDisk();

  // Send cancellation email to this customer
  await sendCancellationEmail(booking);

  // Broadcast live cancellation event to admin subscribers
  broadcastLiveEvent('BOOKING_CANCELLED', {
    pnr: booking.pnr,
    id: booking.id,
    refundAmount: booking.refundAmount,
    cancelledAt: booking.cancelledAt,
  }, `Booking #${booking.pnr} cancelled. Refund of $${booking.refundAmount} initiated.`);

  res.json({
    success: true,
    booking,
    message: `Booking #${booking.pnr} has been cancelled. Refund of $${booking.refundAmount} has been processed.`,
  });
});

// RETRY RESEND EMAIL CONFIRMATION
apiRouter.post('/bookings/:id/resend-email', async (req: Request, res: Response) => {
  const { id } = req.params;
  const booking = bookingsStore.find((b) => b.id === id);
  if (!booking) {
    res.status(404).json({ error: 'Booking not found.' });
    return;
  }

  const appBaseUrl = process.env.APP_URL?.trim() || `${req.protocol}://${req.get('host')}`;
  const result = await sendBookingConfirmationEmail(booking, appBaseUrl);

  if (result.status === 'SENT') {
    booking.emailConfirmationSent = true;
    booking.emailDeliveryStatus = 'DELIVERED';
    booking.emailConfirmationId = result.resendId;
    booking.emailDeliveryError = undefined;
  } else if (result.status === 'SIMULATED') {
    booking.emailConfirmationSent = true;
    booking.emailDeliveryStatus = 'SIMULATED';
    booking.emailDeliveryError = undefined;
  } else {
    booking.emailConfirmationSent = false;
    booking.emailDeliveryStatus = 'FAILED';
    booking.emailDeliveryError = result.error;
  }

  saveStoreToDisk();

  res.json({
    success: result.status !== 'FAILED',
    deliveryStatus: booking.emailDeliveryStatus,
    error: booking.emailDeliveryError,
    resendId: result.resendId,
  });
});

// -------------------------------------------------------------
// ADMIN OPERATIONS (Authorized admin only, flights, email logs)
// -------------------------------------------------------------
// -------------------------------------------------------------
// PUBLIC EXCHANGE RATES API (Live Synced with Fallback)
// -------------------------------------------------------------
apiRouter.get('/exchange-rates', async (_req: Request, res: Response) => {
  const data = await fetchLiveExchangeRates();
  res.json(data);
});

// -------------------------------------------------------------
// REAL-TIME WEATHER FORECAST & AVIATION RISK API (Open-Meteo)
// -------------------------------------------------------------
apiRouter.get('/weather/airport/:code', async (req: Request, res: Response) => {
  const code = (req.params.code || '').toUpperCase();
  const airport = AIRPORTS.find((a) => a.code.toUpperCase() === code);
  const weather = await getAirportWeather(
    code,
    airport?.name,
    airport?.city,
    airport?.country
  );
  res.json(weather);
});

apiRouter.get('/weather/flight/:flightId', async (req: Request, res: Response) => {
  const { flightId } = req.params;
  const flight = flightsStore.find((f) => f.id === flightId);

  if (!flight) {
    res.status(404).json({ error: 'Flight not found' });
    return;
  }

  const [depWeather, arrWeather] = await Promise.all([
    getAirportWeather(
      flight.origin.code,
      flight.origin.name,
      flight.origin.city,
      flight.origin.country
    ),
    getAirportWeather(
      flight.destination.code,
      flight.destination.name,
      flight.destination.city,
      flight.destination.country
    ),
  ]);

  // Overall risk is maximum of departure and arrival risk
  const riskLevels: ('LOW' | 'MODERATE' | 'HIGH' | 'SEVERE')[] = ['LOW', 'MODERATE', 'HIGH', 'SEVERE'];
  const depRiskIdx = riskLevels.indexOf(depWeather.weatherRisk.level);
  const arrRiskIdx = riskLevels.indexOf(arrWeather.weatherRisk.level);
  const overallRisk = depRiskIdx >= arrRiskIdx ? depWeather.weatherRisk.level : arrWeather.weatherRisk.level;
  const operationalReview = depWeather.weatherRisk.flaggedForOperationalReview || arrWeather.weatherRisk.flaggedForOperationalReview;

  const advisories: string[] = [];
  if (depWeather.weatherRisk.reason && depWeather.weatherRisk.level !== 'LOW') {
    advisories.push(`${flight.origin.code} Departure: ${depWeather.weatherRisk.reason}`);
  }
  if (arrWeather.weatherRisk.reason && arrWeather.weatherRisk.level !== 'LOW') {
    advisories.push(`${flight.destination.code} Arrival: ${arrWeather.weatherRisk.reason}`);
  }

  res.json({
    flightId: flight.id,
    flightNumber: flight.flightNumber,
    airline: flight.airline,
    departureAirport: depWeather,
    arrivalAirport: arrWeather,
    overallRisk,
    operationalReviewRequired: operationalReview,
    advisorySummary: advisories.length > 0 ? advisories.join(' | ') : 'Optimal meteorological conditions along flight path.',
    disclaimer: 'AeroWings Weather-Risk Advisory: Provided for situational awareness and dispatch monitoring. Official flight schedule changes require authorized airline operations.',
  });
});

// -------------------------------------------------------------
// ADMIN OPERATIONS (Authorized admin only)
// -------------------------------------------------------------
function requireAdminAuth(req: Request, res: Response, next: NextFunction) {
  const adminHeader = (req.headers['x-admin-email'] || req.headers['authorization']) as string | undefined;
  const adminEmail = (req.query?.adminEmail || (req.body && req.body.adminEmail)) as string | undefined;
  const candidate = (adminHeader || adminEmail || '').replace('Bearer ', '').trim().toLowerCase();

  const user = usersStore.find((u) => u.email.toLowerCase() === candidate || u.id === candidate);
  if (!user || user.role !== 'admin') {
    res.status(403).json({ error: 'Unauthorized: Administrator access required.' });
    return;
  }
  next();
}

// REALTIME LIVE SSE STREAM FOR ADMIN DASHBOARDS
apiRouter.get('/admin/live-stream', requireAdminAuth, (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  const cleanup = registerLiveClient(res);

  req.on('close', () => {
    cleanup();
  });
});

// 1. ALL DATABASE BOOKINGS WITH SEARCH, FILTERS & SERVER-SIDE PAGINATION
apiRouter.get('/admin/bookings', requireAdminAuth, (req: Request, res: Response) => {
  const query = req.query || {};
  const search = ((query.search as string) || '').trim().toLowerCase();
  const bookingStatus = ((query.bookingStatus as string) || 'ALL').toUpperCase();
  const paymentStatus = ((query.paymentStatus as string) || 'ALL').toUpperCase();
  const airline = ((query.airline as string) || 'ALL').trim().toLowerCase();
  const route = ((query.route as string) || '').trim().toLowerCase();
  const startDate = query.startDate as string | undefined;
  const endDate = query.endDate as string | undefined;
  const sortBy = (query.sortBy as string) || 'createdAt';
  const sortOrder = (query.sortOrder as string) === 'asc' ? 'asc' : 'desc';
  const page = Math.max(1, parseInt(query.page as string, 10) || 1);
  const limit = Math.max(1, Math.min(100, parseInt(query.limit as string, 10) || 10));

  // Enrich bookings with customer name from user account or passenger manifest
  let results = bookingsStore.map((b) => {
    const matchedUser = usersStore.find(
      (u) => u.id === b.userId || u.email.toLowerCase() === b.contactEmail.toLowerCase()
    );
    const customerName =
      matchedUser?.name ||
      b.customerName ||
      (b.passengers[0] ? `${b.passengers[0].title} ${b.passengers[0].firstName} ${b.passengers[0].lastName}` : 'Guest Customer');

    return {
      ...b,
      customerName,
      lastUpdated: b.cancelledAt || b.confirmedAt || b.createdAt,
      originalCurrency: b.originalCurrency || 'USD',
      originalAmount: b.originalAmount || b.fareBreakdown.totalAmount,
    };
  });

  // Calculate summary counts across all database bookings before filtering
  const summary = {
    totalCount: bookingsStore.length,
    confirmedCount: bookingsStore.filter((b) => b.bookingStatus === 'CONFIRMED').length,
    pendingCount: bookingsStore.filter((b) => b.bookingStatus === 'PENDING').length,
    cancelledCount: bookingsStore.filter((b) => b.bookingStatus === 'CANCELLED').length,
    refundedCount: bookingsStore.filter((b) => b.paymentStatus === 'REFUNDED').length,
  };

  // Filter: Search query across PNR, booking ID, customer name, email, flight number, route
  if (search) {
    results = results.filter((b) => {
      const pnrMatch = b.pnr.toLowerCase().includes(search);
      const idMatch = b.id.toLowerCase().includes(search);
      const emailMatch = b.contactEmail.toLowerCase().includes(search);
      const phoneMatch = b.contactPhone?.toLowerCase().includes(search);
      const nameMatch = b.customerName.toLowerCase().includes(search);
      const flightNumMatch = b.flight.flightNumber.toLowerCase().includes(search);
      const originMatch =
        b.flight.origin.code.toLowerCase().includes(search) ||
        b.flight.origin.city.toLowerCase().includes(search);
      const destMatch =
        b.flight.destination.code.toLowerCase().includes(search) ||
        b.flight.destination.city.toLowerCase().includes(search);
      const paxMatch = b.passengers.some(
        (p) =>
          `${p.firstName} ${p.lastName}`.toLowerCase().includes(search) ||
          p.passportNumber?.toLowerCase().includes(search)
      );
      return (
        pnrMatch ||
        idMatch ||
        emailMatch ||
        phoneMatch ||
        nameMatch ||
        flightNumMatch ||
        originMatch ||
        destMatch ||
        paxMatch
      );
    });
  }

  // Filter: Booking Status
  if (bookingStatus !== 'ALL') {
    results = results.filter((b) => b.bookingStatus === bookingStatus);
  }

  // Filter: Payment Status
  if (paymentStatus !== 'ALL') {
    results = results.filter((b) => b.paymentStatus === paymentStatus);
  }

  // Filter: Airline
  if (airline !== 'all' && airline) {
    results = results.filter((b) => b.flight.airline.toLowerCase() === airline);
  }

  // Filter: Route
  if (route) {
    results = results.filter((b) => {
      const routeStr = `${b.flight.origin.code}-${b.flight.destination.code}`.toLowerCase();
      const originCity = b.flight.origin.city.toLowerCase();
      const destCity = b.flight.destination.city.toLowerCase();
      return (
        routeStr.includes(route) ||
        originCity.includes(route) ||
        destCity.includes(route) ||
        b.flight.origin.code.toLowerCase() === route ||
        b.flight.destination.code.toLowerCase() === route
      );
    });
  }

  // Filter: Date Range (createdAt)
  if (startDate) {
    const start = new Date(startDate).getTime();
    results = results.filter((b) => new Date(b.createdAt).getTime() >= start);
  }
  if (endDate) {
    const end = new Date(endDate).getTime() + 86400000; // include end of day
    results = results.filter((b) => new Date(b.createdAt).getTime() <= end);
  }

  // Sorting
  results.sort((a, b) => {
    let comparison = 0;
    if (sortBy === 'totalAmount') {
      comparison = a.fareBreakdown.totalAmount - b.fareBreakdown.totalAmount;
    } else if (sortBy === 'departureTime') {
      comparison = new Date(a.flight.departureTime).getTime() - new Date(b.flight.departureTime).getTime();
    } else if (sortBy === 'pnr') {
      comparison = a.pnr.localeCompare(b.pnr);
    } else {
      // Default: createdAt
      comparison = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    }
    return sortOrder === 'asc' ? comparison : -comparison;
  });

  const total = results.length;
  const totalPages = Math.ceil(total / limit) || 1;
  const startIndex = (page - 1) * limit;
  const paginatedBookings = results.slice(startIndex, startIndex + limit);

  res.json({
    bookings: paginatedBookings,
    total,
    page,
    limit,
    totalPages,
    summary,
  });
});

// AUTHORIZED STATUS UPDATES FOR BOOKINGS
apiRouter.patch('/admin/bookings/:id/status', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const { bookingStatus, paymentStatus, cancellationReason } = req.body || {};

  const booking = bookingsStore.find((b) => b.id === id);
  if (!booking) {
    res.status(404).json({ error: 'Booking not found' });
    return;
  }

  const previousStatus = booking.bookingStatus;

  if (bookingStatus && ['CONFIRMED', 'CANCELLED', 'PENDING'].includes(bookingStatus)) {
    booking.bookingStatus = bookingStatus;
    if (bookingStatus === 'CANCELLED' && previousStatus !== 'CANCELLED') {
      booking.cancelledAt = new Date().toISOString();
      booking.cancellationReason = cancellationReason || 'Operations Administrator Administrative Cancellation';
      booking.paymentStatus = 'REFUNDED';
      booking.refundAmount = Number((booking.fareBreakdown.totalAmount * 0.9).toFixed(2));
      // Restore available seats on flight
      const flight = flightsStore.find((f) => f.id === booking.flightId);
      if (flight && flight.availableSeats[booking.cabinClass] !== undefined) {
        flight.availableSeats[booking.cabinClass] += booking.passengers.length;
      }
    } else if (bookingStatus === 'CONFIRMED' && !booking.confirmedAt) {
      booking.confirmedAt = new Date().toISOString();
    }
  }

  if (paymentStatus && ['PAID', 'PENDING', 'REFUNDED'].includes(paymentStatus)) {
    booking.paymentStatus = paymentStatus;
    if (paymentStatus === 'REFUNDED' && !booking.refundAmount) {
      booking.refundAmount = Number((booking.fareBreakdown.totalAmount * 0.9).toFixed(2));
    }
  }

  saveStoreToDisk();

  broadcastLiveEvent(
    'BOOKING_UPDATED',
    {
      id: booking.id,
      pnr: booking.pnr,
      bookingStatus: booking.bookingStatus,
      paymentStatus: booking.paymentStatus,
      lastUpdated: new Date().toISOString(),
    },
    `Booking #${booking.pnr} status updated to ${booking.bookingStatus} (${booking.paymentStatus})`
  );

  res.json({ success: true, booking });
});

// 2. COMPLETE AIRLINE PASSENGER RESERVATIONS ROSTER
apiRouter.get('/admin/passengers', requireAdminAuth, (req: Request, res: Response) => {
  const query = req.query || {};
  const search = ((query.search as string) || '').trim().toLowerCase();
  const bookingStatus = ((query.bookingStatus as string) || 'ALL').toUpperCase();
  const airline = ((query.airline as string) || 'ALL').trim().toLowerCase();
  const cabinClass = ((query.cabinClass as string) || 'ALL').toLowerCase();
  const date = query.date as string | undefined;
  const sortBy = (query.sortBy as string) || 'bookingCreatedAt';
  const sortOrder = (query.sortOrder as string) === 'asc' ? 'asc' : 'desc';
  const page = Math.max(1, parseInt(query.page as string, 10) || 1);
  const limit = Math.max(1, Math.min(100, parseInt(query.limit as string, 10) || 10));

  // Flatten passengers through the actual database bookings relationship without duplicates
  const allPassengerRecords: any[] = [];
  const seenKeys = new Set<string>();

  for (const b of bookingsStore) {
    const matchedUser = usersStore.find(
      (u) => u.id === b.userId || u.email.toLowerCase() === b.contactEmail.toLowerCase()
    );

    for (let i = 0; i < b.passengers.length; i++) {
      const p = b.passengers[i];
      const uniqueKey = `${b.id}_${p.id || i}`;
      if (seenKeys.has(uniqueKey)) continue;
      seenKeys.add(uniqueKey);

      allPassengerRecords.push({
        passengerId: p.id || `pax_${i}`,
        bookingId: b.id,
        pnr: b.pnr,
        customerName: matchedUser?.name || `${b.passengers[0]?.firstName} ${b.passengers[0]?.lastName}`,
        title: p.title,
        firstName: p.firstName,
        lastName: p.lastName,
        fullName: `${p.title} ${p.firstName} ${p.lastName}`.trim(),
        dateOfBirth: p.dateOfBirth,
        gender: p.gender,
        passportNumber: p.passportNumber || 'N/A',
        nationality: p.nationality || 'Unspecified',
        mealPreference: p.mealPreference || 'Regular',
        seatNumber: p.seatNumber || 'Standard Allocated',
        seatType: p.seatType || 'standard',
        seatFee: p.seatFee || 0,
        baggage: p.baggage || {
          cabinAllowance: b.cabinClass === 'business' || b.cabinClass === 'first' ? '2 Cabin Bags (14-18 kg)' : '1 Cabin Bag (7 kg)',
          checkedAllowance: b.cabinClass === 'business' || b.cabinClass === 'first' ? '2 Pieces (64 kg)' : '1 Piece (23 kg)',
        },
        flightId: b.flight.id,
        flightNumber: b.flight.flightNumber,
        airline: b.flight.airline,
        aircraft: b.flight.aircraft,
        route: `${b.flight.origin.code} → ${b.flight.destination.code}`,
        originCode: b.flight.origin.code,
        destinationCode: b.flight.destination.code,
        originCity: b.flight.origin.city,
        destinationCity: b.flight.destination.city,
        departureTime: b.flight.departureTime,
        arrivalTime: b.flight.arrivalTime,
        cabinClass: b.cabinClass,
        bookingStatus: b.bookingStatus,
        paymentStatus: b.paymentStatus,
        contactEmail: b.contactEmail,
        contactPhone: b.contactPhone,
        bookingCreatedAt: b.createdAt,
      });
    }
  }

  let filtered = [...allPassengerRecords];

  // Search filter
  if (search) {
    filtered = filtered.filter((p) => {
      return (
        p.fullName.toLowerCase().includes(search) ||
        p.pnr.toLowerCase().includes(search) ||
        p.passportNumber.toLowerCase().includes(search) ||
        p.flightNumber.toLowerCase().includes(search) ||
        p.contactEmail.toLowerCase().includes(search) ||
        p.route.toLowerCase().includes(search) ||
        p.originCity.toLowerCase().includes(search) ||
        p.destinationCity.toLowerCase().includes(search)
      );
    });
  }

  // Booking status filter
  if (bookingStatus !== 'ALL') {
    filtered = filtered.filter((p) => p.bookingStatus === bookingStatus);
  }

  // Airline filter
  if (airline !== 'all' && airline) {
    filtered = filtered.filter((p) => p.airline.toLowerCase() === airline);
  }

  // Cabin filter
  if (cabinClass !== 'all' && cabinClass) {
    filtered = filtered.filter((p) => p.cabinClass.toLowerCase() === cabinClass);
  }

  // Date filter (travel date)
  if (date) {
    filtered = filtered.filter((p) => p.departureTime.startsWith(date) || p.bookingCreatedAt.startsWith(date));
  }

  // Sorting
  filtered.sort((a, b) => {
    let cmp = 0;
    if (sortBy === 'fullName') {
      cmp = a.fullName.localeCompare(b.fullName);
    } else if (sortBy === 'departureTime') {
      cmp = new Date(a.departureTime).getTime() - new Date(b.departureTime).getTime();
    } else if (sortBy === 'flightNumber') {
      cmp = a.flightNumber.localeCompare(b.flightNumber);
    } else if (sortBy === 'pnr') {
      cmp = a.pnr.localeCompare(b.pnr);
    } else {
      // Default: bookingCreatedAt
      cmp = new Date(a.bookingCreatedAt).getTime() - new Date(b.bookingCreatedAt).getTime();
    }
    return sortOrder === 'asc' ? cmp : -cmp;
  });

  const total = filtered.length;
  const bookingCount = new Set(filtered.map((p) => p.bookingId)).size;
  const totalPages = Math.ceil(total / limit) || 1;
  const startIndex = (page - 1) * limit;
  const paginatedPassengers = filtered.slice(startIndex, startIndex + limit);

  res.json({
    passengers: paginatedPassengers,
    total,
    bookingCount,
    page,
    limit,
    totalPages,
  });
});

// 6. ADMIN PORTAL — OVERVIEW & METRICS (Strict database calculations with date-range filter)
apiRouter.get('/admin/metrics', requireAdminAuth, (req: Request, res: Response) => {
  const query = req.query || {};
  const range = (query.range as string) || 'all';
  const customStart = query.startDate as string | undefined;
  const customEnd = query.endDate as string | undefined;

  let minTime = 0;
  let maxTime = Number.MAX_SAFE_INTEGER;
  const now = Date.now();

  if (range === '7d') {
    minTime = now - 7 * 86400000;
  } else if (range === '30d') {
    minTime = now - 30 * 86400000;
  } else if (range === '90d') {
    minTime = now - 90 * 86400000;
  } else if (range === 'custom') {
    if (customStart) minTime = new Date(customStart).getTime();
    if (customEnd) maxTime = new Date(customEnd).getTime() + 86400000;
  }

  const inScopeBookings = bookingsStore.filter((b) => {
    const t = new Date(b.createdAt).getTime();
    return t >= minTime && t <= maxTime;
  });

  // Strict metric calculations:
  // Exclude failed or unpaid transactions from revenue
  // Do NOT count cancelled or refunded bookings as active confirmed bookings!
  const totalBookings = inScopeBookings.length;
  const confirmedBookings = inScopeBookings.filter((b) => b.bookingStatus === 'CONFIRMED').length;
  const pendingBookings = inScopeBookings.filter((b) => b.bookingStatus === 'PENDING').length;
  const cancelledBookings = inScopeBookings.filter((b) => b.bookingStatus === 'CANCELLED').length;
  const totalPassengers = inScopeBookings.reduce((sum, b) => sum + b.passengers.length, 0);

  const successfulPaidBookings = inScopeBookings.filter(
    (b) => b.paymentStatus === 'PAID' && b.bookingStatus === 'CONFIRMED'
  );
  const successfulPaymentsCount = successfulPaidBookings.length;
  const successfulRevenueUSD = Number(
    successfulPaidBookings.reduce((sum, b) => sum + b.fareBreakdown.totalAmount, 0).toFixed(2)
  );

  const refundedBookings = inScopeBookings.filter(
    (b) => b.paymentStatus === 'REFUNDED' || b.refundAmount !== undefined
  );
  const refundsCount = refundedBookings.length;
  const refundsTotalUSD = Number(
    refundedBookings.reduce((sum, b) => sum + (b.refundAmount || b.fareBreakdown.totalAmount * 0.9), 0).toFixed(2)
  );
  const netRevenueUSD = Number(Math.max(0, successfulRevenueUSD - refundsTotalUSD).toFixed(2));

  // Group bookings over time by date (YYYY-MM-DD)
  const dateMap = new Map<string, { date: string; bookings: number; revenue: number }>();
  for (const b of inScopeBookings) {
    const dStr = b.createdAt.split('T')[0];
    const curr = dateMap.get(dStr) || { date: dStr, bookings: 0, revenue: 0 };
    curr.bookings += 1;
    if (b.bookingStatus === 'CONFIRMED' && b.paymentStatus === 'PAID') {
      curr.revenue += b.fareBreakdown.totalAmount;
    }
    dateMap.set(dStr, curr);
  }
  const bookingsOverTime = Array.from(dateMap.values())
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((item) => ({ ...item, revenue: Number(item.revenue.toFixed(2)) }));

  // Top routes distribution
  const routeMap = new Map<string, { route: string; origin: string; destination: string; count: number; passengers: number; revenue: number }>();
  for (const b of inScopeBookings) {
    const rKey = `${b.flight.origin.code}-${b.flight.destination.code}`;
    const curr = routeMap.get(rKey) || {
      route: rKey,
      origin: `${b.flight.origin.city} (${b.flight.origin.code})`,
      destination: `${b.flight.destination.city} (${b.flight.destination.code})`,
      count: 0,
      passengers: 0,
      revenue: 0,
    };
    curr.count += 1;
    curr.passengers += b.passengers.length;
    if (b.bookingStatus === 'CONFIRMED' && b.paymentStatus === 'PAID') {
      curr.revenue += b.fareBreakdown.totalAmount;
    }
    routeMap.set(rKey, curr);
  }
  const topRoutes = Array.from(routeMap.values())
    .sort((a, b) => b.count - a.count)
    .slice(0, 8)
    .map((r) => ({ ...r, revenue: Number(r.revenue.toFixed(2)) }));

  // Airline distribution
  const airlineMap = new Map<string, { airline: string; count: number; revenue: number }>();
  for (const b of inScopeBookings) {
    const aName = b.flight.airline;
    const curr = airlineMap.get(aName) || { airline: aName, count: 0, revenue: 0 };
    curr.count += 1;
    if (b.bookingStatus === 'CONFIRMED' && b.paymentStatus === 'PAID') {
      curr.revenue += b.fareBreakdown.totalAmount;
    }
    airlineMap.set(aName, curr);
  }
  const airlineDistribution = Array.from(airlineMap.values())
    .map((a) => ({
      ...a,
      percentage: totalBookings > 0 ? Number(((a.count / totalBookings) * 100).toFixed(1)) : 0,
      revenue: Number(a.revenue.toFixed(2)),
    }))
    .sort((a, b) => b.count - a.count);

  // Cabin distribution
  const cabinMap = new Map<string, { cabinClass: string; count: number; passengers: number; revenue: number }>();
  for (const b of inScopeBookings) {
    const cName = b.cabinClass;
    const curr = cabinMap.get(cName) || { cabinClass: cName, count: 0, passengers: 0, revenue: 0 };
    curr.count += 1;
    curr.passengers += b.passengers.length;
    if (b.bookingStatus === 'CONFIRMED' && b.paymentStatus === 'PAID') {
      curr.revenue += b.fareBreakdown.totalAmount;
    }
    cabinMap.set(cName, curr);
  }
  const cabinDistribution = Array.from(cabinMap.values()).map((c) => ({
    ...c,
    percentage: totalBookings > 0 ? Number(((c.count / totalBookings) * 100).toFixed(1)) : 0,
    revenue: Number(c.revenue.toFixed(2)),
  }));

  res.json({
    dateRange: range,
    totalBookings,
    confirmedBookings,
    pendingBookings,
    cancelledBookings,
    totalPassengers,
    successfulPaymentsCount,
    successfulRevenueUSD,
    refundsCount,
    refundsTotalUSD,
    netRevenueUSD,
    bookingsOverTime,
    topRoutes,
    airlineDistribution,
    cabinDistribution,
    activeFlightsCount: flightsStore.length,
    lastCalculatedAt: new Date().toISOString(),
  });
});

// 10. BAGGAGE POLICIES MANAGEMENT
apiRouter.get('/admin/baggage-policies', requireAdminAuth, (_req: Request, res: Response) => {
  res.json({
    policies: getAllBaggagePolicies(),
    options: getAdditionalBaggageOptions(),
  });
});

apiRouter.post('/admin/baggage-policies', requireAdminAuth, (req: Request, res: Response) => {
  const { policies, options } = req.body || {};
  if (Array.isArray(policies)) {
    updateBaggagePolicies(policies, Array.isArray(options) ? options : undefined);
    res.json({ success: true, message: 'Baggage policies updated successfully.' });
  } else {
    res.status(400).json({ error: 'Invalid policies payload' });
  }
});

// LEGACY ADMIN STATS (Preserved for backward compatibility)
apiRouter.get('/admin/stats', requireAdminAuth, (_req: Request, res: Response) => {
  const totalRevenue = bookingsStore
    .filter((b) => b.bookingStatus === 'CONFIRMED' && b.paymentStatus === 'PAID')
    .reduce((sum, b) => sum + b.fareBreakdown.totalAmount, 0);
  const confirmedBookings = bookingsStore.filter((b) => b.bookingStatus === 'CONFIRMED').length;
  const cancelledBookings = bookingsStore.filter((b) => b.bookingStatus === 'CANCELLED').length;

  res.json({
    totalRevenue,
    totalBookings: bookingsStore.length,
    confirmedBookings,
    cancelledBookings,
    activeFlights: flightsStore.length,
    emailLogsCount: emailLogsStore.length,
  });
});

apiRouter.get('/admin/emails', requireAdminAuth, (_req: Request, res: Response) => {
  res.json(emailLogsStore);
});

apiRouter.post('/admin/flights', requireAdminAuth, (req: Request, res: Response) => {
  const body = req.body || {};
  const { flightNumber, aircraft, originCode, destinationCode, departureTime, arrivalTime, prices } = body;

  const originAirport = AIRPORTS.find((a) => a.code === originCode);
  const destAirport = AIRPORTS.find((a) => a.code === destinationCode);

  if (!originAirport || !destAirport) {
    res.status(400).json({ error: 'Origin or destination airport code not recognized.' });
    return;
  }

  const newFlight: Flight = {
    id: 'fl_' + Math.random().toString(36).substring(2, 8),
    flightNumber: flightNumber || 'AW-' + Math.floor(100 + Math.random() * 900),
    airline: 'AeroWings',
    aircraft: aircraft || 'Airbus A350-900',
    origin: originAirport,
    destination: destAirport,
    departureTime: departureTime || new Date(Date.now() + 86400000 * 3).toISOString(),
    arrivalTime: arrivalTime || new Date(Date.now() + 86400000 * 3 + 28800000).toISOString(),
    duration: '8h 00m',
    stops: 0,
    prices: prices || { economy: 450, premiumEconomy: 720, business: 1600, first: 3100 },
    availableSeats: { economy: 50, premiumEconomy: 18, business: 12, first: 4 },
    status: 'SCHEDULED',
    gate: 'T1-10',
  };

  flightsStore.unshift(newFlight);
  saveStoreToDisk();
  broadcastLiveEvent('FLIGHT_STATUS_UPDATED', newFlight, `New flight schedule ${newFlight.flightNumber} added`);
  res.status(201).json(newFlight);
});

apiRouter.patch('/admin/flights/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const body = req.body || {};
  const { status, gate } = body;

  const flight = flightsStore.find((f) => f.id === id);
  if (!flight) {
    res.status(404).json({ error: 'Flight not found.' });
    return;
  }

  if (status) flight.status = status;
  if (gate) flight.gate = gate;

  saveStoreToDisk();
  broadcastLiveEvent('FLIGHT_STATUS_UPDATED', flight, `Flight ${flight.flightNumber} status updated to ${flight.status}`);
  res.json({ success: true, flight });
});

// -------------------------------------------------------------
// DEVELOPMENT EMAIL TEST LAB & TEMPLATE PREVIEW SUITE
// (Safe, Free Development Testing Mode)
// -------------------------------------------------------------

apiRouter.get('/dev/email-templates', (req: Request, res: Response) => {
  const appBaseUrl = process.env.APP_URL?.trim() || `${req.protocol}://${req.get('host')}`;
  const sampleEmail = 'customer.traveler@example.com';
  const sampleOtp = '849201';

  // Sample booking for template preview
  const sampleBooking: Booking = bookingsStore[0] || {
    id: 'bkg_sample_preview',
    pnr: 'AW-TK942',
    verificationToken: 'c0a8019b882f4d1e90ac128790ba45f129c7b91a',
    flightId: 'fl-101',
    flight: flightsStore[0],
    cabinClass: 'business',
    passengers: [
      {
        id: 'pax-sample-1',
        title: 'Ms',
        firstName: 'Sarah',
        lastName: 'Connor',
        dateOfBirth: '1992-06-14',
        gender: 'female',
        passportNumber: 'A94829104',
        nationality: 'United States',
        mealPreference: 'regular',
        seatNumber: '3A',
        seatType: 'window',
        seatFee: 40,
      },
    ],
    contactEmail: sampleEmail,
    contactPhone: '+1 (555) 234-5678',
    fareBreakdown: {
      baseFare: 1650,
      taxesAndFees: 198,
      seatSelectionFee: 40,
      totalAmount: 1888,
      currency: 'USD',
    },
    paymentStatus: 'PAID',
    paymentMethod: 'Visa ending in 4242',
    paymentTransactionId: 'tx_aeropay_preview',
    bookingStatus: 'CONFIRMED',
    createdAt: new Date().toISOString(),
    confirmedAt: new Date().toISOString(),
    emailConfirmationSent: true,
    emailDeliveryStatus: 'SIMULATED',
    ticketGenerated: true,
  };

  const regOtp = renderOtpEmailHtml(sampleOtp, sampleEmail, 'REGISTRATION');
  const bookingOtp = renderOtpEmailHtml(sampleOtp, sampleEmail, 'BOOKING_VERIFY');
  const pwResetOtp = renderOtpEmailHtml(sampleOtp, sampleEmail, 'PASSWORD_RESET');
  const bookingConfirm = renderBookingConfirmationEmailHtml(sampleBooking, appBaseUrl);
  const cancellation = renderCancellationEmailHtml(sampleBooking);

  res.json({
    templates: [
      {
        id: 'registration-otp',
        name: 'Account Registration Verification (OTP)',
        type: 'REGISTRATION',
        recipientSource: 'Direct form input entered by customer during sign up',
        sampleRecipient: sampleEmail,
        subject: regOtp.subject,
        html: regOtp.html,
      },
      {
        id: 'booking-verify-otp',
        name: 'Booking Payment & Passenger Security (OTP)',
        type: 'BOOKING_VERIFY',
        recipientSource: 'Contact email entered in Traveler Details / customer account',
        sampleRecipient: sampleEmail,
        subject: bookingOtp.subject,
        html: bookingOtp.html,
      },
      {
        id: 'password-reset-otp',
        name: 'Password Recovery Verification (OTP)',
        type: 'PASSWORD_RESET',
        recipientSource: 'Verified account email retrieved from database user record',
        sampleRecipient: sampleEmail,
        subject: pwResetOtp.subject,
        html: pwResetOtp.html,
      },
      {
        id: 'booking-confirmation',
        name: 'Booking Confirmation & Verifiable E-Ticket Link',
        type: 'BOOKING_CONFIRMATION',
        recipientSource: 'Verified contact email saved in persistent booking record',
        sampleRecipient: sampleEmail,
        subject: bookingConfirm.subject,
        html: bookingConfirm.html,
      },
      {
        id: 'booking-cancellation',
        name: 'Booking Cancellation & Refund Notice',
        type: 'BOOKING_CANCELLATION',
        recipientSource: 'Verified contact email saved in persistent booking record',
        sampleRecipient: sampleEmail,
        subject: cancellation.subject,
        html: cancellation.html,
      },
    ],
    resendTestAddresses: [
      { email: 'delivered@resend.dev', label: 'Delivered (Simulate 200 Success)' },
      { email: 'bounced@resend.dev', label: 'Bounced (Simulate Hard Bounce)' },
      { email: 'complained@resend.dev', label: 'Complained (Simulate Spam Flag)' },
    ],
  });
});

apiRouter.post('/dev/test-dispatch', async (req: Request, res: Response) => {
  const body = req.body || {};
  const { templateType, targetEmail, mode } = body;
  const cleanEmail = (targetEmail || 'delivered@resend.dev').trim().toLowerCase();
  const testMode = mode === 'REAL_RESEND_TEST_RECIPIENT' ? 'REAL_RESEND_TEST_RECIPIENT' : 'SIMULATED';

  const sampleBooking: Booking = bookingsStore[0] || {
    id: 'bkg_sample_preview',
    pnr: 'AW-TK942',
    verificationToken: 'c0a8019b882f4d1e90ac128790ba45f129c7b91a',
    flightId: 'fl-101',
    flight: flightsStore[0],
    cabinClass: 'business',
    passengers: [
      {
        id: 'pax-sample-1',
        title: 'Ms',
        firstName: 'Sarah',
        lastName: 'Connor',
        dateOfBirth: '1992-06-14',
        gender: 'female',
        passportNumber: 'A94829104',
        nationality: 'United States',
        mealPreference: 'regular',
        seatNumber: '3A',
        seatType: 'window',
        seatFee: 40,
      },
    ],
    contactEmail: cleanEmail,
    contactPhone: '+1 (555) 234-5678',
    fareBreakdown: {
      baseFare: 1650,
      taxesAndFees: 198,
      seatSelectionFee: 40,
      totalAmount: 1888,
      currency: 'USD',
    },
    paymentStatus: 'PAID',
    paymentMethod: 'Visa ending in 4242',
    paymentTransactionId: 'tx_aeropay_preview',
    bookingStatus: 'CONFIRMED',
    createdAt: new Date().toISOString(),
    confirmedAt: new Date().toISOString(),
    emailConfirmationSent: true,
    emailDeliveryStatus: 'SIMULATED',
    ticketGenerated: true,
  };

  const appBaseUrl = process.env.APP_URL?.trim() || `${req.protocol}://${req.get('host')}`;

  // If testing simulated mode (Free, 0 cost, zero API calls)
  if (testMode === 'SIMULATED') {
    const isTest = isResendTestRecipient(cleanEmail);
    const testCode = '654321';

    let rendered;
    if (templateType === 'BOOKING_CONFIRMATION') {
      rendered = renderBookingConfirmationEmailHtml(sampleBooking, appBaseUrl);
    } else if (templateType === 'BOOKING_CANCELLATION') {
      rendered = renderCancellationEmailHtml(sampleBooking);
    } else {
      rendered = renderOtpEmailHtml(testCode, cleanEmail, templateType || 'REGISTRATION');
    }

    return res.json({
      success: true,
      mode: 'SIMULATED',
      status: 'SIMULATED',
      label: isTest
        ? `[Resend Sandbox Test Address: ${cleanEmail}] (Simulated outcome testing only - not a real customer delivery)`
        : `[Safe Development Sandbox] Simulated dispatch to ${cleanEmail}`,
      recipient: cleanEmail,
      subject: rendered.subject,
      htmlPreview: rendered.html,
      note: 'Safe development simulation. No external API call was made. Zero cost, zero quota consumed.',
    });
  }

  // Real Resend Test Recipient Dispatch
  let result;
  if (templateType === 'BOOKING_CONFIRMATION') {
    const bookingClone = { ...sampleBooking, contactEmail: cleanEmail };
    result = await sendBookingConfirmationEmail(bookingClone, appBaseUrl);
  } else if (templateType === 'BOOKING_CANCELLATION') {
    const bookingClone = { ...sampleBooking, contactEmail: cleanEmail };
    result = await sendCancellationEmail(bookingClone);
  } else {
    result = await sendOtpEmail(cleanEmail, '982314', templateType || 'REGISTRATION');
  }

  res.json({
    success: result.success,
    mode: 'REAL_RESEND_TEST_RECIPIENT',
    status: result.status,
    recipient: cleanEmail,
    resendId: result.resendId,
    error: result.error,
    isDomainRestriction: result.isDomainRestriction,
    guidance: result.guidance,
    label: isResendTestRecipient(cleanEmail)
      ? `[Resend Sandbox Test Address: ${cleanEmail}] (Simulated outcome testing only - not a real customer delivery)`
      : `Real customer delivery attempt to ${cleanEmail}`,
  });
});

apiRouter.post('/dev/test-otp-lifecycle', (req: Request, res: Response) => {
  const body = req.body || {};
  const { email } = body;
  const testEmail = (email || 'tester@aerowings.dev').trim().toLowerCase();

  const generatedCode = (100000 + crypto.randomInt(900000)).toString();
  const now = Date.now();
  const expiresAt = now + 5 * 60 * 1000;

  // Set test OTP record
  otpStore.set(testEmail, {
    email: testEmail,
    code: generatedCode,
    purpose: 'REGISTRATION',
    createdAt: now,
    expiresAt,
    attempts: 0,
    verified: false,
    lastSentAt: now,
  });

  res.json({
    success: true,
    message: 'OTP lifecycle record initialized in test sandbox.',
    email: testEmail,
    code: generatedCode,
    createdAt: new Date(now).toISOString(),
    expiresAt: new Date(expiresAt).toISOString(),
    ttlSeconds: 300,
    cooldownSeconds: 60,
    maxAttempts: 5,
    lifecycleChecks: {
      validOtpCheck: `POST /api/auth/verify-otp with code ${generatedCode} -> verified: true`,
      wrongOtpCheck: `POST /api/auth/verify-otp with wrong code -> remainingAttempts: 4`,
      expiryCheck: `Verification rejected when now > expiresAt (+5 min)`,
      rateLimitCheck: `Subsequent send-otp within 60s rejected with HTTP 429`,
      singleUseCheck: `Record deleted or consumed upon successful verification`,
    },
  });
});

apiRouter.get('/dev/recipient-mapping-audit', (_req: Request, res: Response) => {
  res.json({
    auditDate: new Date().toISOString(),
    status: 'VERIFIED_CLEAN',
    rulesEnforced: [
      {
        flow: 'Account Registration OTP',
        rule: 'Targets the exact email entered by the customer in the registration request.',
        verifiedByCode: 'POST /api/auth/send-otp with purpose=REGISTRATION uses req.body.email',
      },
      {
        flow: 'Password Reset OTP',
        rule: 'Targets the verified user account email found in the database.',
        verifiedByCode: 'POST /api/auth/forgot-password/request looks up usersStore and dispatches to user.email',
      },
      {
        flow: 'Booking Payment & Passenger OTP',
        rule: 'Targets the verified primary customer email specified in traveler details / user account.',
        verifiedByCode: 'POST /api/auth/send-otp with purpose=BOOKING_VERIFY uses verified contactEmail',
      },
      {
        flow: 'Booking Confirmation Email',
        rule: 'Targets the confirmed customer contactEmail recorded in database booking record.',
        verifiedByCode: 'POST /api/bookings/create dispatches to newBooking.contactEmail',
      },
      {
        flow: 'Booking Cancellation Email',
        rule: 'Targets the customer contactEmail recorded in the persistent database booking record.',
        verifiedByCode: 'POST /api/bookings/:id/cancel dispatches to booking.contactEmail',
      },
      {
        flow: 'Hardcoded Personal Email Check',
        rule: 'Zero hardcoded test addresses. Never uses personal email as recipient or fallback.',
        status: 'PASSED',
      },
    ],
  });
});

export const apiApp = express();
apiApp.use(express.json());
apiApp.use(express.urlencoded({ extended: true }));
apiApp.use(apiRouter);
