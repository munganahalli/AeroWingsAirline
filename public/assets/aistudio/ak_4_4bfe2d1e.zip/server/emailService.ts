import type { Booking, EmailLog } from './types.ts';
import { emailLogsStore, saveStoreToDisk } from './db.ts';

export interface SendEmailResult {
  success: boolean;
  status: 'SENT' | 'SIMULATED' | 'FAILED';
  resendId?: string;
  error?: string;
  simulatedCode?: string;
  isDomainRestriction?: boolean;
  guidance?: string;
}

const getResendConfig = () => {
  const apiKey = process.env.RESEND_API_KEY?.trim() || '';
  const fromEmail = process.env.RESEND_FROM_EMAIL?.trim() || 'AeroWings <onboarding@resend.dev>';
  return { apiKey, fromEmail };
};

// Check if recipient is a documented Resend test address
export function isResendTestRecipient(email: string): boolean {
  const clean = email.trim().toLowerCase();
  return (
    clean === 'delivered@resend.dev' ||
    clean === 'bounced@resend.dev' ||
    clean === 'complained@resend.dev'
  );
}

// Resend recipient restriction error detector
export function parseResendError(errorMsg: string, status?: number): {
  isRestriction: boolean;
  userFriendlyMessage: string;
} {
  const lower = (errorMsg || '').toLowerCase();
  const isRestriction =
    lower.includes('only send testing emails') ||
    lower.includes('validation_error') ||
    lower.includes('not verified') ||
    lower.includes('verify your domain') ||
    status === 403 ||
    status === 422;

  if (isRestriction) {
    return {
      isRestriction: true,
      userFriendlyMessage:
        'Resend Free Sandbox Notice: The default test sender (onboarding@resend.dev) can only send live emails to your verified Resend account owner email. Real delivery to external inboxes requires adding and verifying your custom domain in Resend. In Development Test Mode, you can test all templates, OTP verification, and booking confirmations completely free.',
    };
  }

  return {
    isRestriction: false,
    userFriendlyMessage: errorMsg || 'Email delivery failed through Resend.',
  };
}

export function renderOtpEmailHtml(
  otpCode: string,
  cleanToEmail: string,
  purpose: 'REGISTRATION' | 'LOGIN' | 'PASSWORD_RESET' | 'BOOKING_VERIFY'
): { subject: string; html: string } {
  const purposeLabels: Record<string, string> = {
    REGISTRATION: 'Account Registration Verification',
    LOGIN: 'Sign In Verification',
    PASSWORD_RESET: 'Password Reset Verification',
    BOOKING_VERIFY: 'Booking Payment & Passenger Verification',
  };

  const subject = `AeroWings Verification Code: ${otpCode} [${purposeLabels[purpose] || 'Verification'}]`;

  const html = `
    <div style="font-family: 'Helvetica Neue', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #ffffff; color: #1e293b; border-radius: 12px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 4px 12px rgba(0,0,0,0.05);">
      <div style="background: #002b49; padding: 28px 24px; text-align: center;">
        <h1 style="margin: 0; font-size: 26px; font-weight: 800; letter-spacing: -0.5px; color: #ffffff;">AeroWings</h1>
        <p style="margin: 4px 0 0; font-size: 13px; color: #bae6fd; letter-spacing: 1px;">PREMIER GLOBAL AIRLINES</p>
      </div>
      <div style="padding: 32px 28px; background: #ffffff;">
        <h2 style="margin: 0 0 12px; font-size: 18px; color: #0f172a; font-weight: 700;">${purposeLabels[purpose] || 'Email Verification'}</h2>
        <p style="margin: 0 0 20px; color: #475569; font-size: 14px; line-height: 1.6;">
          Please use the following 6-digit one-time verification code to proceed. This security code is valid for <strong>5 minutes</strong>.
        </p>
        <div style="background: #f8fafc; border: 2px dashed #0284c7; border-radius: 10px; padding: 22px; text-align: center; margin-bottom: 24px;">
          <span style="font-size: 34px; font-weight: 800; letter-spacing: 10px; color: #002b49; font-family: monospace;">${otpCode}</span>
        </div>
        <p style="margin: 0 0 16px; font-size: 12px; color: #64748b; line-height: 1.5;">
          • This OTP is strictly valid for single use only.<br/>
          • Dispatched directly to: <strong>${cleanToEmail}</strong><br/>
          • AeroWings customer service will never ask for your verification code.<br/>
          • If you did not initiate this request, you can safely disregard this email.
        </p>
      </div>
      <div style="padding: 16px 24px; background: #f8fafc; text-align: center; font-size: 12px; color: #94a3b8; border-top: 1px solid #e2e8f0;">
        © ${new Date().getFullYear()} AeroWings Airlines Ltd. Official Passenger Reservations.
      </div>
    </div>
  `;

  return { subject, html };
}

export async function sendOtpEmail(
  toEmail: string,
  otpCode: string,
  purpose: 'REGISTRATION' | 'LOGIN' | 'PASSWORD_RESET' | 'BOOKING_VERIFY'
): Promise<SendEmailResult> {
  const cleanToEmail = toEmail.trim().toLowerCase();
  const { apiKey, fromEmail } = getResendConfig();
  const { subject, html } = renderOtpEmailHtml(otpCode, cleanToEmail, purpose);

  const isTestAddress = isResendTestRecipient(cleanToEmail);
  const isKeyConfigured = apiKey && !apiKey.includes('1234567890abcdef') && apiKey.startsWith('re_');

  // Secure server logging without exposing full raw code to untrusted logs
  const maskedEmail = cleanToEmail.replace(/^(.)(.*)(@.*)$/, (_, a, b, c) => `${a}***${c}`);
  console.log(`[AeroWings Email Service] OTP dispatched to recipient: ${maskedEmail} (Purpose: ${purpose})`);

  if (isKeyConfigured) {
    try {
      const response = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: fromEmail,
          to: [cleanToEmail],
          subject: isTestAddress ? `[Resend Sandbox Test] ${subject}` : subject,
          html,
        }),
      });

      const data = await response.json().catch(() => ({}));

      if (response.ok && data?.id) {
        logEmail({
          to: cleanToEmail,
          subject: isTestAddress ? `[Resend Test] ${subject}` : subject,
          type: 'OTP',
          status: 'SENT',
          resendId: data.id,
        });
        return { success: true, status: 'SENT', resendId: data.id };
      } else {
        const rawError = data?.message || `Resend HTTP error ${response.status}`;
        const { isRestriction, userFriendlyMessage } = parseResendError(rawError, response.status);

        logEmail({
          to: cleanToEmail,
          subject,
          type: 'OTP',
          status: 'FAILED',
          errorMessage: userFriendlyMessage,
        });

        return {
          success: false,
          status: 'FAILED',
          error: userFriendlyMessage,
          isDomainRestriction: isRestriction,
          guidance: isRestriction
            ? 'Resend sandbox allows sending to your own registered email or delivered@resend.dev. To send to arbitrary customer emails, verify your domain in Resend.'
            : undefined,
        };
      }
    } catch (err: any) {
      const errorMsg = err?.message || 'Network error calling Resend API';
      logEmail({
        to: cleanToEmail,
        subject,
        type: 'OTP',
        status: 'FAILED',
        errorMessage: errorMsg,
      });
      return {
        success: false,
        status: 'FAILED',
        error: errorMsg,
      };
    }
  } else {
    // Development preview / test mode (Safe, zero-cost, no external API call)
    logEmail({
      to: cleanToEmail,
      subject,
      type: 'OTP',
      status: 'SIMULATED',
      errorMessage: 'Development Test Mode (Simulated dispatch, safe & free without external Resend call)',
    });
    return {
      success: true,
      status: 'SIMULATED',
      simulatedCode: otpCode,
    };
  }
}

export function renderBookingConfirmationEmailHtml(
  booking: Booking,
  appBaseUrl?: string
): { subject: string; html: string } {
  const passengerNames = booking.passengers
    .map((p) => `${p.title} ${p.firstName} ${p.lastName} (${p.seatNumber ? `Seat ${p.seatNumber}` : 'Standard Seat'})`)
    .join(', ');

  const baseUrl = appBaseUrl || process.env.APP_URL || 'http://localhost:3000';
  const verificationLink = `${baseUrl}/booking/verify/${booking.verificationToken}`;

  const subject = `Confirmed: AeroWings Flight Booking #${booking.pnr} - ${booking.flight.origin.code} to ${booking.flight.destination.code}`;

  const html = `
    <div style="font-family: 'Helvetica Neue', Arial, sans-serif; max-width: 640px; margin: 0 auto; background: #ffffff; color: #0f172a; border-radius: 12px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 4px 16px rgba(0,0,0,0.06);">
      <div style="background: #002b49; padding: 28px 24px; text-align: center;">
        <h1 style="margin: 0; font-size: 26px; font-weight: 800; letter-spacing: -0.5px; color: #ffffff;">AeroWings</h1>
        <p style="margin: 4px 0 0; font-size: 13px; color: #bae6fd; letter-spacing: 1px;">ELECTRONIC FLIGHT TICKET & BOOKING CONFIRMATION</p>
      </div>

      <div style="padding: 26px 28px; background: #ffffff;">
        <div style="background: #f0fdf4; border: 1px solid #86efac; border-radius: 8px; padding: 16px 20px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center;">
          <div>
            <span style="font-size: 11px; color: #166534; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; display: block;">Booking Reference (PNR)</span>
            <span style="font-size: 24px; font-weight: 800; color: #002b49; letter-spacing: 2px;">${booking.pnr}</span>
          </div>
          <div style="text-align: right;">
            <span style="font-size: 12px; color: #15803d; font-weight: 700; background: #dcfce7; padding: 4px 10px; border-radius: 6px; text-transform: uppercase;">CONFIRMED</span>
          </div>
        </div>

        <h3 style="margin: 0 0 14px; font-size: 15px; color: #0f172a; font-weight: 700; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px;">Itinerary Details</h3>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 24px; font-size: 13px;">
          <tr>
            <td style="padding: 6px 0; color: #64748b; width: 35%;">Flight Number</td>
            <td style="padding: 6px 0; color: #0f172a; font-weight: 700;">${booking.flight.flightNumber} (${booking.flight.airline})</td>
          </tr>
          <tr>
            <td style="padding: 6px 0; color: #64748b;">Aircraft</td>
            <td style="padding: 6px 0; color: #0f172a;">${booking.flight.aircraft}</td>
          </tr>
          <tr>
            <td style="padding: 6px 0; color: #64748b;">Routing</td>
            <td style="padding: 6px 0; color: #0284c7; font-weight: 700;">
              ${booking.flight.origin.city} (${booking.flight.origin.code}) → ${booking.flight.destination.city} (${booking.flight.destination.code})
            </td>
          </tr>
          <tr>
            <td style="padding: 6px 0; color: #64748b;">Departure</td>
            <td style="padding: 6px 0; color: #0f172a;">${new Date(booking.flight.departureTime).toUTCString()} (Terminal ${booking.flight.origin.terminal || '1'})</td>
          </tr>
          <tr>
            <td style="padding: 6px 0; color: #64748b;">Arrival</td>
            <td style="padding: 6px 0; color: #0f172a;">${new Date(booking.flight.arrivalTime).toUTCString()} (Terminal ${booking.flight.destination.terminal || '2'})</td>
          </tr>
          <tr>
            <td style="padding: 6px 0; color: #64748b;">Cabin Class</td>
            <td style="padding: 6px 0; color: #0f172a; text-transform: capitalize; font-weight: 600;">${booking.cabinClass}</td>
          </tr>
        </table>

        <h3 style="margin: 0 0 12px; font-size: 15px; color: #0f172a; font-weight: 700; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px;">Passenger Manifest</h3>
        <p style="margin: 0 0 20px; font-size: 13px; color: #334155; line-height: 1.6;">${passengerNames}</p>

        <h3 style="margin: 0 0 12px; font-size: 15px; color: #0f172a; font-weight: 700; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px;">Fare Breakdown</h3>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 13px;">
          <tr>
            <td style="padding: 4px 0; color: #64748b;">Base Airfare</td>
            <td style="padding: 4px 0; color: #0f172a; text-align: right; font-mono: true;">$${booking.fareBreakdown.baseFare.toFixed(2)} USD</td>
          </tr>
          <tr>
            <td style="padding: 4px 0; color: #64748b;">Airport Taxes & Security Fees</td>
            <td style="padding: 4px 0; color: #0f172a; text-align: right; font-mono: true;">$${booking.fareBreakdown.taxesAndFees.toFixed(2)} USD</td>
          </tr>
          ${booking.fareBreakdown.seatSelectionFee > 0 ? `
          <tr>
            <td style="padding: 4px 0; color: #64748b;">Seat Selection Fee</td>
            <td style="padding: 4px 0; color: #0f172a; text-align: right; font-mono: true;">$${booking.fareBreakdown.seatSelectionFee.toFixed(2)} USD</td>
          </tr>` : ''}
          <tr style="border-top: 1px solid #cbd5e1; font-size: 14px; font-weight: 700;">
            <td style="padding: 10px 0; color: #002b49;">Total Paid (${booking.paymentMethod})</td>
            <td style="padding: 10px 0; color: #002b49; text-align: right;">$${booking.fareBreakdown.totalAmount.toFixed(2)} USD</td>
          </tr>
        </table>

        <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px; text-align: center; margin-top: 24px;">
          <p style="margin: 0 0 8px; font-size: 13px; color: #334155; font-weight: 600;">Verifiable Electronic Flight Ticket Link</p>
          <a href="${verificationLink}" style="display: inline-block; padding: 10px 20px; background: #002b49; color: #ffffff; text-decoration: none; border-radius: 6px; font-size: 12px; font-weight: bold;">
            View & Verify Official Ticket Online
          </a>
          <p style="margin: 8px 0 0; font-size: 11px; color: #94a3b8;">
            You can download your PDF ticket with its scannable QR code anytime from your AeroWings profile.
          </p>
        </div>
      </div>

      <div style="padding: 16px 24px; background: #f8fafc; text-align: center; font-size: 12px; color: #94a3b8; border-top: 1px solid #e2e8f0;">
        © ${new Date().getFullYear()} AeroWings Airlines. Customer Support: bookings@aerowings.com
      </div>
    </div>
  `;

  return { subject, html };
}

export async function sendBookingConfirmationEmail(booking: Booking, appBaseUrl?: string): Promise<SendEmailResult> {
  const { apiKey, fromEmail } = getResendConfig();
  const toEmail = booking.contactEmail.trim().toLowerCase();
  const { subject, html } = renderBookingConfirmationEmailHtml(booking, appBaseUrl);

  const isTestAddress = isResendTestRecipient(toEmail);
  const isKeyConfigured = apiKey && !apiKey.includes('1234567890abcdef') && apiKey.startsWith('re_');

  // Secure server logging without exposing sensitive passenger private data
  const maskedEmail = toEmail.replace(/^(.)(.*)(@.*)$/, (_, a, b, c) => `${a}***${c}`);
  console.log(`[AeroWings Email Service] Booking confirmation dispatched to recipient: ${maskedEmail} (PNR: ${booking.pnr})`);

  if (isKeyConfigured) {
    try {
      const response = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: fromEmail,
          to: [toEmail],
          subject: isTestAddress ? `[Resend Sandbox Test] ${subject}` : subject,
          html,
        }),
      });

      const data = await response.json().catch(() => ({}));

      if (response.ok && data?.id) {
        logEmail({
          to: toEmail,
          subject: isTestAddress ? `[Resend Test] ${subject}` : subject,
          type: 'BOOKING_CONFIRMATION',
          status: 'SENT',
          resendId: data.id,
          pnr: booking.pnr,
        });
        return { success: true, status: 'SENT', resendId: data.id };
      } else {
        const rawError = data?.message || `Resend HTTP error ${response.status}`;
        const { isRestriction, userFriendlyMessage } = parseResendError(rawError, response.status);

        logEmail({
          to: toEmail,
          subject,
          type: 'BOOKING_CONFIRMATION',
          status: 'FAILED',
          errorMessage: userFriendlyMessage,
          pnr: booking.pnr,
        });

        return {
          success: false,
          status: 'FAILED',
          error: userFriendlyMessage,
          isDomainRestriction: isRestriction,
          guidance: isRestriction
            ? 'Resend sandbox allows sending to your own registered email or delivered@resend.dev. To send to arbitrary customer emails, verify your domain in Resend.'
            : undefined,
        };
      }
    } catch (err: any) {
      const errorMsg = err?.message || 'Network error calling Resend';
      logEmail({
        to: toEmail,
        subject,
        type: 'BOOKING_CONFIRMATION',
        status: 'FAILED',
        errorMessage: errorMsg,
        pnr: booking.pnr,
      });
      return {
        success: false,
        status: 'FAILED',
        error: errorMsg,
      };
    }
  } else {
    // Development simulation
    logEmail({
      to: toEmail,
      subject,
      type: 'BOOKING_CONFIRMATION',
      status: 'SIMULATED',
      errorMessage: 'Development Test Mode (Simulated dispatch, safe & free without external Resend call)',
      pnr: booking.pnr,
    });
    return {
      success: true,
      status: 'SIMULATED',
    };
  }
}

export function renderCancellationEmailHtml(booking: Booking): { subject: string; html: string } {
  const subject = `Cancellation Confirmed: AeroWings Booking #${booking.pnr}`;

  const html = `
    <div style="font-family: 'Helvetica Neue', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #ffffff; color: #1e293b; border-radius: 12px; overflow: hidden; border: 1px solid #e2e8f0;">
      <div style="background: #991b1b; padding: 24px; text-align: center;">
        <h1 style="margin: 0; font-size: 24px; font-weight: 800; color: #ffffff;">AeroWings</h1>
        <p style="margin: 4px 0 0; font-size: 13px; color: #fecaca;">BOOKING CANCELLATION NOTICE</p>
      </div>
      <div style="padding: 24px 28px; background: #ffffff;">
        <h2 style="margin: 0 0 12px; font-size: 18px; color: #0f172a;">Your Booking Has Been Cancelled</h2>
        <p style="margin: 0 0 16px; color: #475569; font-size: 14px; line-height: 1.6;">
          Your flight reservation with PNR <strong>${booking.pnr}</strong> (${booking.flight.origin.code} → ${booking.flight.destination.code}) has been cancelled as requested.
        </p>
        <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin-bottom: 20px;">
          <p style="margin: 0 0 8px; font-size: 13px; color: #334155;"><strong>Reason:</strong> ${booking.cancellationReason || 'Customer requested online cancellation'}</p>
          <p style="margin: 0; font-size: 13px; color: #15803d; font-weight: 700;"><strong>Refund Initiated:</strong> $${(booking.refundAmount || booking.fareBreakdown.totalAmount * 0.9).toFixed(2)} USD</p>
        </div>
        <p style="margin: 0; font-size: 12px; color: #64748b;">
          Refunds are credited to the original payment method (${booking.paymentMethod}) within 5-7 business days.
        </p>
      </div>
      <div style="padding: 16px 24px; background: #f8fafc; text-align: center; font-size: 12px; color: #94a3b8; border-top: 1px solid #e2e8f0;">
        © ${new Date().getFullYear()} AeroWings Airlines Ltd.
      </div>
    </div>
  `;

  return { subject, html };
}

export async function sendCancellationEmail(booking: Booking): Promise<SendEmailResult> {
  const { apiKey, fromEmail } = getResendConfig();
  const toEmail = booking.contactEmail.trim().toLowerCase();
  const { subject, html } = renderCancellationEmailHtml(booking);

  const isTestAddress = isResendTestRecipient(toEmail);
  const isKeyConfigured = apiKey && !apiKey.includes('1234567890abcdef') && apiKey.startsWith('re_');

  if (isKeyConfigured) {
    try {
      const response = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: fromEmail,
          to: [toEmail],
          subject: isTestAddress ? `[Resend Sandbox Test] ${subject}` : subject,
          html,
        }),
      });

      const data = await response.json().catch(() => ({}));

      if (response.ok && data?.id) {
        logEmail({
          to: toEmail,
          subject: isTestAddress ? `[Resend Test] ${subject}` : subject,
          type: 'BOOKING_CANCELLATION',
          status: 'SENT',
          resendId: data.id,
          pnr: booking.pnr,
        });
        return { success: true, status: 'SENT', resendId: data.id };
      }
    } catch (err: any) {
      logEmail({
        to: toEmail,
        subject,
        type: 'BOOKING_CANCELLATION',
        status: 'FAILED',
        errorMessage: err.message,
        pnr: booking.pnr,
      });
    }
  }

  logEmail({
    to: toEmail,
    subject,
    type: 'BOOKING_CANCELLATION',
    status: 'SIMULATED',
    pnr: booking.pnr,
  });

  return { success: true, status: 'SIMULATED' };
}

function logEmail(log: Omit<EmailLog, 'id' | 'timestamp'>) {
  const record: EmailLog = {
    ...log,
    id: 'eml_' + Math.random().toString(36).substring(2, 10),
    timestamp: new Date().toISOString(),
  };
  emailLogsStore.unshift(record);
  if (emailLogsStore.length > 200) {
    emailLogsStore.pop();
  }
  saveStoreToDisk();
}
