import React, { useState } from 'react';
import { ChevronDown, Globe, LogOut, Plane, Shield, User as UserIcon } from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { useCurrency, type CurrencyCode } from '../context/CurrencyContext.tsx';

interface NavbarProps {
  currentView: 'home' | 'booking' | 'my-bookings' | 'verify' | 'admin';
  onNavigate: (view: 'home' | 'booking' | 'my-bookings' | 'verify' | 'admin') => void;
  onOpenSignIn: () => void;
  onOpenSignUp: () => void;
}

export function Navbar({ currentView, onNavigate, onOpenSignIn, onOpenSignUp }: NavbarProps) {
  const { user, logout } = useAuth();
  const { currency, setCurrency, allCurrencies } = useCurrency();
  const [currencyDropdownOpen, setCurrencyDropdownOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200 bg-white shadow-xs">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4 px-4 sm:px-6 py-3.5">
        {/* Brand Wordmark */}
        <button
          onClick={() => onNavigate('home')}
          className="flex items-center gap-2.5 text-left text-xl font-bold tracking-tight text-blue-950 whitespace-nowrap shrink-0 hover:opacity-90 transition-opacity"
        >
          <div className="w-8 h-8 rounded-lg bg-blue-900 flex items-center justify-center text-white shadow-xs">
            <Plane className="w-4 h-4 -rotate-45" />
          </div>
          <span className="font-extrabold tracking-tight text-lg sm:text-xl">
            Aero<span className="text-blue-700">Wings</span>
          </span>
        </button>

        {/* Navigation Links */}
        <nav className="hidden lg:flex items-center gap-6 text-xs sm:text-sm font-semibold text-slate-600">
          <button
            onClick={() => onNavigate('home')}
            className={`whitespace-nowrap transition-colors pb-1 border-b-2 ${
              currentView === 'home'
                ? 'border-blue-900 text-blue-900 font-bold'
                : 'border-transparent hover:text-blue-900'
            }`}
          >
            Search Flights
          </button>
          <button
            onClick={() => onNavigate('booking')}
            className={`whitespace-nowrap transition-colors pb-1 border-b-2 ${
              currentView === 'booking'
                ? 'border-blue-900 text-blue-900 font-bold'
                : 'border-transparent hover:text-blue-900'
            }`}
          >
            Book Flight (5 Steps)
          </button>
          <button
            onClick={() => onNavigate('my-bookings')}
            className={`whitespace-nowrap transition-colors pb-1 border-b-2 ${
              currentView === 'my-bookings'
                ? 'border-blue-900 text-blue-900 font-bold'
                : 'border-transparent hover:text-blue-900'
            }`}
          >
            My Bookings
          </button>
          <button
            onClick={() => onNavigate('verify')}
            className={`whitespace-nowrap transition-colors pb-1 border-b-2 ${
              currentView === 'verify'
                ? 'border-blue-900 text-blue-900 font-bold'
                : 'border-transparent hover:text-blue-900'
            }`}
          >
            Verify Ticket
          </button>
          <button
            onClick={() => onNavigate('admin')}
            className={`whitespace-nowrap transition-colors flex items-center gap-1.5 pb-1 border-b-2 ${
              currentView === 'admin'
                ? 'border-blue-900 text-blue-900 font-bold'
                : 'border-transparent hover:text-blue-900'
            }`}
          >
            <Shield className="w-3.5 h-3.5 text-slate-500" />
            <span>Admin & Test Lab</span>
            <span className="hidden xl:inline text-[9px] px-1.5 py-0.2 rounded bg-blue-100 text-blue-800 font-bold">
              Test Mode
            </span>
          </button>
        </nav>

        {/* Right Section: Currency Selector & User Actions */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* International Currency Selector (Requirement 7) */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setCurrencyDropdownOpen(!currencyDropdownOpen)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-800 text-xs font-bold transition-colors shadow-xs"
              title="Select Display Currency"
            >
              <Globe className="w-3.5 h-3.5 text-blue-900" />
              <span>{currency.flag}</span>
              <span className="font-mono">{currency.code}</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {currencyDropdownOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setCurrencyDropdownOpen(false)}
                />
                <div className="absolute right-0 mt-2 w-56 rounded-xl bg-white border border-slate-200 shadow-xl py-2 z-50 text-xs">
                  <div className="px-3 py-1.5 text-[10px] uppercase font-bold text-slate-400 tracking-wider border-b border-slate-100">
                    Select Currency
                  </div>
                  {allCurrencies.map((c) => (
                    <button
                      key={c.code}
                      type="button"
                      onClick={() => {
                        setCurrency(c.code as CurrencyCode);
                        setCurrencyDropdownOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3.5 py-2 text-left hover:bg-slate-50 transition-colors ${
                        currency.code === c.code ? 'bg-blue-50 text-blue-900 font-bold' : 'text-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-base">{c.flag}</span>
                        <div>
                          <div className="font-semibold">{c.code} ({c.symbol})</div>
                          <div className="text-[10px] text-slate-400">{c.name}</div>
                        </div>
                      </div>
                      <span className="text-[10px] font-mono text-slate-500">
                        {c.code === 'USD' ? 'Base' : `1$ = ${c.rateFromUSD}`}
                      </span>
                    </button>
                  ))}
                  <div className="px-3 pt-2 mt-1 border-t border-slate-100 text-[10px] text-slate-400">
                    Fares converted at benchmark rates.
                  </div>
                </div>
              </>
            )}
          </div>

          {/* User Sign In / Sign Up buttons */}
          {user ? (
            <div className="flex items-center gap-2">
              <div className="hidden sm:flex items-center gap-2 text-xs text-slate-800 bg-slate-100 border border-slate-200 px-3 py-1.5 rounded-lg">
                <UserIcon className="w-3.5 h-3.5 text-blue-900" />
                <span className="font-bold truncate max-w-[120px]">{user.name}</span>
                {user.role === 'admin' && (
                  <span className="text-[10px] text-blue-900 font-extrabold bg-blue-100 border border-blue-200 px-1.5 py-0.5 rounded">
                    ADMIN
                  </span>
                )}
              </div>
              <button
                onClick={logout}
                title="Sign Out"
                className="p-2 text-slate-500 hover:text-rose-600 hover:bg-slate-100 rounded-lg transition-colors"
                aria-label="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={onOpenSignIn}
                className="px-3 py-1.5 text-xs font-bold text-slate-700 hover:text-blue-900 hover:bg-slate-100 rounded-lg transition-colors whitespace-nowrap shrink-0"
              >
                Sign In
              </button>
              <button
                onClick={onOpenSignUp}
                className="px-3.5 py-1.5 text-xs font-bold text-white bg-blue-900 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0 shadow-xs"
              >
                Sign Up
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
