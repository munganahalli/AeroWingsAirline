import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  ArrowLeft,
  CheckCircle2,
  CreditCard,
  Lock,
  Mail,
  RefreshCw,
  ShieldCheck,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import { useCurrency } from '../../context/CurrencyContext.tsx';
import { createBooking, sendOtp, verifyOtp } from '../../lib/api.ts';
import type { Booking, BookingDraft } from '../../types/index.ts';

interface Step5Props {
  draft: BookingDraft;
  onBookingSuccess: (booking: Booking) => void;
  onBack: () => void;
}

export function Step5PayAndVerifyOtp({ draft, onBookingSuccess, onBack }: Step5Props) {
  const { user } = useAuth();
  const { formatPrice, currency } = useCurrency();

  // Payment state
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'aeropay' | 'wire'>('card');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvc, setCardCvc] = useState('');
  const [cardName, setCardName] = useState('');

  // Email OTP state
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [otpVerified, setOtpVerified] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const [expirySeconds, setExpirySeconds] = useState(300);
  const [simulatedNotice, setSimulatedNotice] = useState<string | null>(null);

  // Flow & error state
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [idempotencyKey] = useState(() => 'bkg_' + Math.random().toString(36).substring(2, 10));

  // Cooldown countdown
  useEffect(() => {
    let timer: any;
    if (cooldown > 0) {
      timer = setInterval(() => setCooldown((c) => c - 1), 1000);
    }
    return () => clearInterval(timer);
  }, [cooldown]);

  // 5-minute expiry countdown
  useEffect(() => {
    let timer: any;
    if (otpSent && expirySeconds > 0) {
      timer = setInterval(() => setExpirySeconds((e) => e - 1), 1000);
    }
    return () => clearInterval(timer);
  }, [otpSent, expirySeconds]);

  // Auto-send OTP on step mount to customer's exact email address
  useEffect(() => {
    if (!otpSent && draft.contactEmail) {
      handleSendOtp();
    }
  }, [draft.contactEmail]);

  const handleSendOtp = async () => {
    setError(null);
    setLoading(true);
    try {
      const res = await sendOtp(draft.contactEmail, 'BOOKING_VERIFY');
      setOtpSent(true);
      setCooldown(res.cooldownSeconds || 60);
      setExpirySeconds(300);
      if (res.simulatedCode) {
        setSimulatedNotice(
          `[Development Preview]: Verification OTP sent to ${draft.contactEmail}: ${res.simulatedCode}`
        );
      }
    } catch (err: any) {
      setError(err.message || 'Failed to dispatch verification code to your email.');
    } finally {
      setLoading(false);
    }
  };

  const handlePayAndConfirm = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // 1. Validate payment details
    if (paymentMethod === 'card') {
      if (cardNumber.replace(/\s/g, '').length < 16) {
        setError('Please enter a valid 16-digit payment card number.');
        return;
      }
      if (!cardExpiry || !cardCvc || !cardName.trim()) {
        setError('Please complete all card details (Name on Card, Expiry, CVV).');
        return;
      }
    }

    // 2. Validate OTP
    if (!otpCode || otpCode.trim().length !== 6) {
      setError('Please enter the 6-digit email verification code.');
      return;
    }

    setLoading(true);
    try {
      // Step A: Verify OTP with server if not already verified
      if (!otpVerified) {
        await verifyOtp(draft.contactEmail, otpCode.trim(), 'BOOKING_VERIFY');
        setOtpVerified(true);
      }

      if (!user) {
        setError('You must sign in or create an account to complete booking payment.');
        setLoading(false);
        return;
      }

      // Step B: Submit booking creation & payment simulation
      const paymentDescriptor =
        paymentMethod === 'card'
          ? `Card ending in ${cardNumber.slice(-4) || '4242'}`
          : paymentMethod === 'aeropay'
          ? 'AeroPay Instant Flight Wallet'
          : 'Wire Transfer / Electronic Bank Transfer';

      const res = await createBooking({
        flightId: draft.flight!.id,
        cabinClass: draft.cabinClass,
        passengers: draft.passengers,
        contactEmail: draft.contactEmail,
        contactPhone: draft.contactPhone,
        fareBreakdown: draft.fareBreakdown,
        paymentMethod: paymentDescriptor,
        otpCode: otpCode.trim(),
        userId: user.id,
        idempotencyKey,
      });

      if (res.booking) {
        onBookingSuccess(res.booking);
      }
    } catch (err: any) {
      setError(err.message || 'Payment authorization or booking confirmation failed.');
    } finally {
      setLoading(false);
    }
  };

  const formattedTotal = formatPrice(draft.fareBreakdown.totalAmount);

  return (
    <form onSubmit={handlePayAndConfirm} className="space-y-6">
      {/* Step Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-xl bg-white border border-slate-200 shadow-xs">
        <div>
          <span className="text-xs font-bold text-blue-900 tracking-wider uppercase">Final Step 5</span>
          <h2 className="text-xl font-bold text-slate-900 mt-0.5">Pay & Verify Email OTP</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Security verification and instant electronic ticket issuance
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono font-bold text-blue-950 bg-blue-50 border border-blue-200 px-3 py-1.5 rounded-lg">
          <Lock className="w-3.5 h-3.5" />
          <span>Amount: {formattedTotal} (${draft.fareBreakdown.totalAmount.toFixed(2)} USD)</span>
        </div>
      </div>

      {error && (
        <div
          className={`flex items-start gap-2.5 p-3.5 rounded-xl border text-xs leading-relaxed ${
            error.includes('Resend Free Sandbox')
              ? 'bg-amber-50 border-amber-200 text-amber-900'
              : 'bg-rose-50 border-rose-200 text-rose-700'
          }`}
        >
          <AlertCircle
            className={`w-4 h-4 shrink-0 mt-0.5 ${
              error.includes('Resend Free Sandbox') ? 'text-amber-600' : 'text-rose-500'
            }`}
          />
          <div>
            <div className="font-bold">
              {error.includes('Resend Free Sandbox') ? 'Resend Free Sandbox Notice' : 'Verification Issue'}
            </div>
            <div className="mt-0.5">{error}</div>
          </div>
        </div>
      )}

      {simulatedNotice && (
        <div className="flex items-start gap-2.5 p-3 rounded-lg bg-blue-50 border border-blue-200 text-blue-800 text-xs">
          <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-blue-700" />
          <span>{simulatedNotice}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* LEFT COLUMN: PAYMENT METHOD */}
        <div className="p-6 rounded-2xl bg-white border border-slate-200 space-y-4 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
              <CreditCard className="w-4 h-4 text-blue-900" />
              <span>1. Payment Details (Simulated Gateway)</span>
            </div>
            <span className="text-[10px] text-amber-800 font-bold bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">
              Simulated Processing
            </span>
          </div>

          {/* Payment Method Selector */}
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => setPaymentMethod('card')}
              className={`p-3 rounded-xl border text-left transition-all ${
                paymentMethod === 'card'
                  ? 'bg-blue-50 border-blue-600 text-blue-950 font-bold shadow-xs'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              <div className="text-xs">Credit/Debit</div>
              <div className="text-[10px] text-slate-500 mt-0.5">Visa / MC / Amex</div>
            </button>
            <button
              type="button"
              onClick={() => setPaymentMethod('aeropay')}
              className={`p-3 rounded-xl border text-left transition-all ${
                paymentMethod === 'aeropay'
                  ? 'bg-blue-50 border-blue-600 text-blue-950 font-bold shadow-xs'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              <div className="text-xs">AeroPay</div>
              <div className="text-[10px] text-slate-500 mt-0.5">Flight Wallet</div>
            </button>
            <button
              type="button"
              onClick={() => setPaymentMethod('wire')}
              className={`p-3 rounded-xl border text-left transition-all ${
                paymentMethod === 'wire'
                  ? 'bg-blue-50 border-blue-600 text-blue-950 font-bold shadow-xs'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              <div className="text-xs">Bank Wire</div>
              <div className="text-[10px] text-slate-500 mt-0.5">Direct Transfer</div>
            </button>
          </div>

          {paymentMethod === 'card' && (
            <div className="space-y-3 pt-2">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Name on Card</label>
                <input
                  type="text"
                  required
                  value={cardName}
                  onChange={(e) => setCardName(e.target.value)}
                  placeholder="e.g. Elena Rostova"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-sm text-slate-900 focus:outline-none focus:border-blue-700 focus:bg-white transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Card Number</label>
                <div className="relative">
                  <CreditCard className="absolute left-3.5 top-2.5 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    required
                    maxLength={19}
                    value={cardNumber}
                    onChange={(e) => {
                      const v = e.target.value.replace(/\D/g, '').replace(/(.{4})/g, '$1 ').trim();
                      setCardNumber(v);
                    }}
                    placeholder="4242 4242 4242 4242"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-10 pr-3.5 py-2 text-sm text-slate-900 font-mono focus:outline-none focus:border-blue-700 focus:bg-white transition-colors"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Expiry Date</label>
                  <input
                    type="text"
                    required
                    maxLength={5}
                    value={cardExpiry}
                    onChange={(e) => setCardExpiry(e.target.value)}
                    placeholder="MM/YY"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-sm text-slate-900 font-mono focus:outline-none focus:border-blue-700 focus:bg-white transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">CVV / CVC</label>
                  <input
                    type="password"
                    required
                    maxLength={4}
                    value={cardCvc}
                    onChange={(e) => setCardCvc(e.target.value.replace(/\D/g, ''))}
                    placeholder="123"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-sm text-slate-900 font-mono focus:outline-none focus:border-blue-700 focus:bg-white transition-colors"
                  />
                </div>
              </div>
            </div>
          )}

          {paymentMethod === 'aeropay' && (
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 space-y-2">
              <p>
                AeroPay Flight Wallet will authorize <strong>${draft.fareBreakdown.totalAmount.toFixed(2)} USD</strong> ({formattedTotal}) directly upon OTP validation.
              </p>
              <div className="flex items-center gap-2 text-emerald-700 font-bold">
                <CheckCircle2 className="w-4 h-4" />
                <span>Wallet Connected • Zero transaction fee</span>
              </div>
            </div>
          )}

          {paymentMethod === 'wire' && (
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 space-y-2">
              <p>Direct electronic bank settlement through SWIFT/ACH network.</p>
              <p className="text-slate-500">Guaranteed instant airline ticket reservation lock.</p>
            </div>
          )}

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-500 flex items-center gap-2">
            <Lock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>256-bit TLS encrypted transaction. Payment is securely processed upon OTP verification.</span>
          </div>
        </div>

        {/* RIGHT COLUMN: EMAIL OTP SECURITY VERIFICATION */}
        <div className="p-6 rounded-2xl bg-white border border-slate-200 space-y-4 shadow-xs">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100 text-sm font-bold text-slate-900">
            <Mail className="w-4 h-4 text-blue-900" />
            <span>2. Mandatory Customer Email Verification</span>
          </div>

          <div className="text-xs text-slate-600 leading-relaxed">
            To prevent fraud and guarantee delivery of your official Electronic Ticket, a 6-digit code was dispatched exclusively to:
            <div className="font-bold text-blue-950 font-mono text-sm mt-1.5 p-2.5 rounded-lg bg-blue-50 border border-blue-200">
              {draft.contactEmail}
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5 text-center">
              Enter 6-Digit Verification Code
            </label>
            <div className="relative">
              <input
                type="text"
                maxLength={6}
                value={otpCode}
                onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                placeholder="000000"
                className="w-full tracking-[8px] text-center text-2xl font-mono font-bold bg-slate-50 border border-slate-300 rounded-xl py-3 text-blue-950 placeholder-slate-400 focus:outline-none focus:border-blue-700 focus:bg-white transition-colors"
              />
              {otpVerified && (
                <div className="absolute right-3.5 top-3.5 text-emerald-600">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
              )}
            </div>

            <div className="flex items-center justify-between text-xs text-slate-500 mt-2.5">
              <span>
                Expires in:{' '}
                <strong className="text-slate-800">
                  {Math.floor(expirySeconds / 60)}:{(expirySeconds % 60).toString().padStart(2, '0')}
                </strong>
              </span>
              <button
                type="button"
                onClick={handleSendOtp}
                disabled={cooldown > 0 || loading}
                className="text-blue-900 hover:text-blue-700 font-bold disabled:text-slate-400 disabled:cursor-not-allowed transition-colors"
              >
                {cooldown > 0 ? `Resend in ${cooldown}s` : 'Resend Code'}
              </button>
            </div>
          </div>

          {/* Security rules list */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 space-y-1.5">
            <div className="font-bold text-slate-800 mb-1">AeroWings Email OTP Rules:</div>
            <div>✓ Valid for 5 minutes with single-use token consumption</div>
            <div>✓ Rate-limited with 60-second cooldown protection</div>
            <div>✓ Dispatched exclusively to customer's contact email</div>
            <div>✓ Confirmed booking email will be sent automatically via Resend</div>
          </div>
        </div>
      </div>

      {/* Navigation Buttons (Backward works cleanly without clearing state!) */}
      <div className="flex items-center justify-between pt-4 border-t border-slate-200">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-2 py-3 px-5 border border-slate-300 hover:border-slate-400 text-slate-700 hover:text-slate-900 font-semibold rounded-xl transition-colors text-sm"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Booking Review</span>
        </button>

        <button
          type="submit"
          disabled={loading || otpCode.length !== 6}
          className="flex items-center gap-2 py-3 px-8 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-xs text-sm"
        >
          {loading ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Processing Payment & Issuing Ticket...</span>
            </>
          ) : (
            <>
              <ShieldCheck className="w-4 h-4" />
              <span>Authorize & Confirm Booking ({formattedTotal})</span>
            </>
          )}
        </button>
      </div>
    </form>
  );
}
