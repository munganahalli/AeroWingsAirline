import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Plane,
  QrCode,
  RefreshCw,
  Search,
  ShieldCheck,
} from 'lucide-react';
import { verifyTicketToken } from '../lib/api.ts';

interface VerificationPageProps {
  initialToken?: string;
  onNavigateHome: () => void;
}

export function VerificationPage({ initialToken, onNavigateHome }: VerificationPageProps) {
  const [tokenInput, setTokenInput] = useState(initialToken || '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [verifiedData, setVerifiedData] = useState<any | null>(null);

  useEffect(() => {
    if (initialToken) {
      handleLookup(initialToken);
    }
  }, [initialToken]);

  const handleLookup = async (tokenToVerify?: string) => {
    const token = (tokenToVerify || tokenInput).trim();
    if (!token) {
      setError('Please provide a valid electronic ticket verification token.');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const data = await verifyTicketToken(token);
      setVerifiedData(data);
    } catch (err: any) {
      setError(err.message || 'Ticket could not be verified in the AeroWings database.');
      setVerifiedData(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      {/* Page Title */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-blue-50 border border-blue-200 text-xs font-bold text-blue-900 shadow-xs">
          <ShieldCheck className="w-3.5 h-3.5 text-blue-700" />
          <span>Official Airline Electronic Gate Validation</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          Verify Flight Ticket
        </h1>
        <p className="text-sm text-slate-500 max-w-lg mx-auto">
          Scan the QR code printed on your AeroWings E-Ticket or enter the cryptographic ticket token below
        </p>
      </div>

      {/* Lookup Bar */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleLookup();
          }}
          className="flex flex-col sm:flex-row gap-3"
        >
          <div className="relative flex-1">
            <QrCode className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={tokenInput}
              onChange={(e) => setTokenInput(e.target.value)}
              placeholder="Paste verification token (e.g. c0a8019b88...)"
              className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-10 pr-4 py-2.5 text-sm font-mono text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-700 focus:bg-white transition-colors"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="flex items-center justify-center gap-2 px-6 py-2.5 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl transition-colors disabled:opacity-50 text-sm shadow-xs"
          >
            {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
            <span>Validate Ticket</span>
          </button>
        </form>
      </div>

      {error && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 flex items-start gap-3 text-rose-800 text-xs">
          <AlertCircle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
          <div>
            <div className="font-bold text-rose-900">Ticket Verification Unsuccessful</div>
            <div className="mt-0.5 leading-relaxed">{error}</div>
          </div>
        </div>
      )}

      {/* Verified Ticket Card */}
      {verifiedData && (
        <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200 shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-6 border-b border-slate-100 gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700">
                  Cryptographically Validated
                </span>
                <h3 className="text-xl font-extrabold text-slate-900">Authentic AeroWings Ticket</h3>
                <span className="text-xs text-blue-900 font-mono font-bold">PNR: {verifiedData.pnr}</span>
              </div>
            </div>

            <div className="text-left sm:text-right">
              <span
                className={`inline-block px-3 py-1 rounded-md text-xs font-bold uppercase tracking-wider ${
                  verifiedData.bookingStatus === 'CONFIRMED'
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                    : 'bg-rose-50 text-rose-800 border border-rose-200'
                }`}
              >
                {verifiedData.bookingStatus}
              </span>
              <div className="text-[11px] text-slate-500 mt-1">
                Issued: {new Date(verifiedData.confirmedAt).toLocaleDateString()}
              </div>
            </div>
          </div>

          {/* Route Overview */}
          <div className="grid grid-cols-3 items-center gap-4 py-2">
            <div>
              <div className="text-3xl font-black text-slate-900">{verifiedData.origin.code}</div>
              <div className="text-xs font-bold text-blue-900">{verifiedData.origin.city}</div>
              <div className="text-[11px] text-slate-500">Terminal {verifiedData.origin.terminal || '1'}</div>
            </div>

            <div className="text-center">
              <div className="text-xs text-slate-600 font-bold mb-1">
                {verifiedData.flightNumber} ({verifiedData.airline})
              </div>
              <div className="relative my-2">
                <div className="h-0.5 bg-slate-200 w-full" />
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white px-2 text-blue-900">
                  <Plane className="w-4 h-4 rotate-90" />
                </div>
              </div>
              <span className="text-[11px] text-emerald-700 font-bold">Valid for Travel</span>
            </div>

            <div className="text-right">
              <div className="text-3xl font-black text-slate-900">{verifiedData.destination.code}</div>
              <div className="text-xs font-bold text-blue-900">{verifiedData.destination.city}</div>
              <div className="text-[11px] text-slate-500">Terminal {verifiedData.destination.terminal || '2'}</div>
            </div>
          </div>

          {/* Verified Details Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-slate-100 text-xs">
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-slate-500 block">Cabin Class</span>
              <span className="font-bold text-slate-900 capitalize mt-0.5 block">{verifiedData.cabinClass}</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-slate-500 block">Aircraft</span>
              <span className="font-bold text-slate-900 mt-0.5 block truncate">{verifiedData.aircraft}</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-slate-500 block">Gate</span>
              <span className="font-bold text-blue-900 font-mono mt-0.5 block">{verifiedData.gate}</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-slate-500 block">Seats</span>
              <span className="font-bold text-slate-900 font-mono mt-0.5 block">{verifiedData.seats?.join(', ')}</span>
            </div>
          </div>

          {/* Masked Passenger Names for Privacy */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1 text-xs">
            <span className="text-slate-700 font-bold block mb-1">
              Authorized Traveler Manifest ({verifiedData.passengerCount}):
            </span>
            <div className="flex flex-wrap gap-2">
              {verifiedData.passengerInitials?.map((init: string, idx: number) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 rounded bg-white border border-slate-300 text-slate-800 font-bold font-mono text-[11px] shadow-xs"
                >
                  {init}
                </span>
              ))}
            </div>
            <p className="text-[10px] text-slate-500 pt-1">
              * Passenger names masked in compliance with airline privacy standards. No passwords, OTPs, or payment credentials are stored or exposed in this verification link.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
