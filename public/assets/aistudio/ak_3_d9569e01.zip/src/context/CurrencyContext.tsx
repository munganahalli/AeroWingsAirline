import React, { createContext, useContext, useEffect, useState } from 'react';

export type CurrencyCode = 'USD' | 'INR' | 'EUR' | 'GBP' | 'AED' | 'CAD' | 'SGD';

export interface CurrencyInfo {
  code: CurrencyCode;
  symbol: string;
  name: string;
  rateFromUSD: number;
  flag: string;
  label: string;
}

export const SUPPORTED_CURRENCIES: Record<CurrencyCode, CurrencyInfo> = {
  USD: {
    code: 'USD',
    symbol: '$',
    name: 'US Dollar',
    rateFromUSD: 1.0,
    flag: '🇺🇸',
    label: 'USD ($)',
  },
  INR: {
    code: 'INR',
    symbol: '₹',
    name: 'Indian Rupee',
    rateFromUSD: 86.5,
    flag: '🇮🇳',
    label: 'INR (₹)',
  },
  EUR: {
    code: 'EUR',
    symbol: '€',
    name: 'Euro',
    rateFromUSD: 0.92,
    flag: '🇪🇺',
    label: 'EUR (€)',
  },
  GBP: {
    code: 'GBP',
    symbol: '£',
    name: 'British Pound',
    rateFromUSD: 0.78,
    flag: '🇬🇧',
    label: 'GBP (£)',
  },
  AED: {
    code: 'AED',
    symbol: 'د.إ',
    name: 'UAE Dirham',
    rateFromUSD: 3.67,
    flag: '🇦🇪',
    label: 'AED (د.إ)',
  },
  CAD: {
    code: 'CAD',
    symbol: 'CA$',
    name: 'Canadian Dollar',
    rateFromUSD: 1.39,
    flag: '🇨🇦',
    label: 'CAD (CA$)',
  },
  SGD: {
    code: 'SGD',
    symbol: 'S$',
    name: 'Singapore Dollar',
    rateFromUSD: 1.34,
    flag: '🇸🇬',
    label: 'SGD (S$)',
  },
};

interface CurrencyContextType {
  currency: CurrencyInfo;
  setCurrency: (code: CurrencyCode) => void;
  formatPrice: (usdAmount: number, overrideCode?: CurrencyCode) => string;
  convertPrice: (usdAmount: number, overrideCode?: CurrencyCode) => number;
  allCurrencies: CurrencyInfo[];
  rateDisclaimer: string;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export function CurrencyProvider({ children }: { children: React.ReactNode }) {
  const [currencyCode, setCurrencyCode] = useState<CurrencyCode>('USD');

  useEffect(() => {
    try {
      const saved = localStorage.getItem('aerowings_display_currency');
      if (saved && SUPPORTED_CURRENCIES[saved as CurrencyCode]) {
        setCurrencyCode(saved as CurrencyCode);
      }
    } catch {
      // ignore
    }
  }, []);

  const handleSetCurrency = (code: CurrencyCode) => {
    if (SUPPORTED_CURRENCIES[code]) {
      setCurrencyCode(code);
      try {
        localStorage.setItem('aerowings_display_currency', code);
      } catch {
        // ignore
      }
    }
  };

  const currency = SUPPORTED_CURRENCIES[currencyCode] || SUPPORTED_CURRENCIES.USD;

  const convertPrice = (usdAmount: number, overrideCode?: CurrencyCode): number => {
    const target = overrideCode ? SUPPORTED_CURRENCIES[overrideCode] : currency;
    const rate = target?.rateFromUSD || 1.0;
    return Number((usdAmount * rate).toFixed(2));
  };

  const formatPrice = (usdAmount: number, overrideCode?: CurrencyCode): string => {
    const target = overrideCode ? SUPPORTED_CURRENCIES[overrideCode] : currency;
    const rate = target?.rateFromUSD || 1.0;
    const converted = Math.round(usdAmount * rate);

    if (target.code === 'INR') {
      return `₹${converted.toLocaleString('en-IN')}`;
    }
    if (target.code === 'EUR') {
      return `€${converted.toLocaleString('de-DE')}`;
    }
    if (target.code === 'GBP') {
      return `£${converted.toLocaleString('en-GB')}`;
    }
    if (target.code === 'AED') {
      return `${converted.toLocaleString('en-US')} AED`;
    }
    if (target.code === 'CAD') {
      return `CA$${converted.toLocaleString('en-US')}`;
    }
    if (target.code === 'SGD') {
      return `S$${converted.toLocaleString('en-US')}`;
    }
    return `$${converted.toLocaleString('en-US')}`;
  };

  const rateDisclaimer =
    'Fares are settled in USD with transparent fixed demonstration benchmark exchange rates. Conversion displays are accurate estimates for international travelers.';

  return (
    <CurrencyContext.Provider
      value={{
        currency,
        setCurrency: handleSetCurrency,
        formatPrice,
        convertPrice,
        allCurrencies: Object.values(SUPPORTED_CURRENCIES),
        rateDisclaimer,
      }}
    >
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  const context = useContext(CurrencyContext);
  if (!context) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
}
