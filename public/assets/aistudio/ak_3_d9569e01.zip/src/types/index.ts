export type CabinClass = 'economy' | 'premiumEconomy' | 'business' | 'first';

export interface Airport {
  code: string;
  name: string;
  city: string;
  country: string;
  category?: 'domestic' | 'international';
  terminal?: string;
}

export interface TravelerCounts {
  adults: number;
  children: number;
  infants: number;
}

export interface Flight {
  id: string;
  flightNumber: string;
  airline: string;
  aircraft: string;
  origin: Airport;
  destination: Airport;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  stops: number;
  prices: {
    economy: number;
    premiumEconomy: number;
    business: number;
    first: number;
  };
  availableSeats: {
    economy: number;
    premiumEconomy: number;
    business: number;
    first: number;
  };
  status: 'SCHEDULED' | 'BOARDING' | 'DEPARTED' | 'DELAYED' | 'CANCELLED';
  gate?: string;
}

export interface Passenger {
  id: string;
  title: 'Mr' | 'Mrs' | 'Ms' | 'Dr' | 'Prof';
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  gender: 'male' | 'female' | 'other';
  passportNumber: string;
  nationality: string;
  mealPreference: 'regular' | 'vegetarian' | 'vegan' | 'halal' | 'kosher' | 'diabetic';
  seatNumber?: string;
  seatType?: 'standard' | 'window' | 'aisle' | 'extra_legroom';
  seatFee?: number;
}

export interface FareBreakdown {
  baseFare: number;
  taxesAndFees: number;
  seatSelectionFee: number;
  totalAmount: number;
  currency: string;
}

export interface Booking {
  id: string;
  userId?: string;
  pnr: string;
  verificationToken: string;
  flightId: string;
  flight: Flight;
  cabinClass: CabinClass;
  passengers: Passenger[];
  contactEmail: string;
  contactPhone: string;
  fareBreakdown: FareBreakdown;
  paymentStatus: 'PAID' | 'PENDING' | 'REFUNDED';
  paymentMethod: string;
  paymentTransactionId: string;
  bookingStatus: 'CONFIRMED' | 'CANCELLED' | 'PENDING';
  createdAt: string;
  confirmedAt?: string;
  cancelledAt?: string;
  cancellationReason?: string;
  refundAmount?: number;
  emailConfirmationSent: boolean;
  emailConfirmationId?: string;
  emailDeliveryStatus: 'DELIVERED' | 'SIMULATED' | 'FAILED' | 'PENDING';
  emailDeliveryError?: string;
  ticketGenerated: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'customer' | 'admin';
}

export interface EmailLog {
  id: string;
  to: string;
  subject: string;
  type: 'OTP' | 'BOOKING_CONFIRMATION' | 'BOOKING_CANCELLATION' | 'PASSWORD_RESET';
  status: 'SENT' | 'SIMULATED' | 'FAILED';
  resendId?: string;
  errorMessage?: string;
  pnr?: string;
  timestamp: string;
}

export type BookingStep = 1 | 2 | 3 | 4 | 5;

export interface BookingDraft {
  flight: Flight | null;
  cabinClass: CabinClass;
  passengers: Passenger[];
  contactEmail: string;
  contactPhone: string;
  fareBreakdown: FareBreakdown;
  selectedSeats: Record<string, string>; // passengerId -> seatNumber
}
