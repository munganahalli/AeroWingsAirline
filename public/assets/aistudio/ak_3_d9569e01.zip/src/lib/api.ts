import type { Airport, Booking, EmailLog, Flight, Passenger, User } from '../types/index.ts';

const BASE_URL = '/api';

export async function fetchConfig() {
  const res = await fetch(`${BASE_URL}/config`);
  if (!res.ok) throw new Error('Failed to load system config');
  return res.json();
}

export async function fetchAirports(): Promise<Airport[]> {
  const res = await fetch(`${BASE_URL}/airports`);
  if (!res.ok) throw new Error('Failed to fetch airports');
  return res.json();
}

export async function fetchFlights(params?: {
  origin?: string;
  destination?: string;
  cabinClass?: string;
  date?: string;
  passengers?: number;
}): Promise<Flight[]> {
  const url = new URL(`${BASE_URL}/flights`, window.location.origin);
  if (params?.origin) url.searchParams.set('origin', params.origin);
  if (params?.destination) url.searchParams.set('destination', params.destination);
  if (params?.cabinClass) url.searchParams.set('cabinClass', params.cabinClass);
  if (params?.date) url.searchParams.set('date', params.date);
  if (params?.passengers) url.searchParams.set('passengers', params.passengers.toString());

  const res = await fetch(url.toString());
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data?.error || `Flight search request failed with status ${res.status}`);
  }
  return Array.isArray(data) ? data : [];
}

export async function sendOtp(
  email: string,
  purpose: 'REGISTRATION' | 'LOGIN' | 'PASSWORD_RESET' | 'BOOKING_VERIFY'
) {
  const res = await fetch(`${BASE_URL}/auth/send-otp`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: email.trim().toLowerCase(), purpose }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to dispatch verification code');
  return data;
}

export async function verifyOtp(email: string, code: string, purpose?: string) {
  const res = await fetch(`${BASE_URL}/auth/verify-otp`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: email.trim().toLowerCase(), code: code.trim(), purpose }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Invalid verification code');
  return data;
}

export async function registerUser(name: string, email: string, password: string): Promise<{ user: User }> {
  const res = await fetch(`${BASE_URL}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: name.trim(), email: email.trim().toLowerCase(), password }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Registration failed');
  return data;
}

export async function loginUser(email: string, password: string): Promise<{ user: User }> {
  const res = await fetch(`${BASE_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: email.trim().toLowerCase(), password }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Authentication failed');
  return data;
}

export async function requestPasswordReset(email: string) {
  const res = await fetch(`${BASE_URL}/auth/forgot-password/request`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: email.trim().toLowerCase() }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Password reset request failed');
  return data;
}

export async function submitPasswordReset(email: string, newPassword: string) {
  const res = await fetch(`${BASE_URL}/auth/forgot-password/reset`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: email.trim().toLowerCase(), newPassword }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to update password');
  return data;
}

export async function createBooking(payload: {
  flightId: string;
  cabinClass: string;
  passengers: Passenger[];
  contactEmail: string;
  contactPhone: string;
  fareBreakdown: any;
  paymentMethod: string;
  otpCode: string;
  userId?: string;
  idempotencyKey?: string;
}): Promise<{ success: boolean; booking: Booking }> {
  let effectiveUserId = payload.userId;
  if (!effectiveUserId) {
    try {
      const stored = localStorage.getItem('aerowings_auth_user');
      if (stored) {
        effectiveUserId = JSON.parse(stored)?.id;
      }
    } catch {
      // ignore
    }
  }

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (effectiveUserId) {
    headers['x-user-id'] = effectiveUserId;
    headers['Authorization'] = `Bearer ${effectiveUserId}`;
  }

  const res = await fetch(`${BASE_URL}/bookings/create`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      ...payload,
      userId: effectiveUserId,
      contactEmail: payload.contactEmail.trim().toLowerCase(),
    }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Booking creation failed');
  return data;
}

export async function fetchMyBookings(email?: string, pnr?: string): Promise<Booking[]> {
  const url = new URL(`${BASE_URL}/bookings/my`, window.location.origin);
  if (email) url.searchParams.set('email', email.trim().toLowerCase());
  if (pnr) url.searchParams.set('pnr', pnr.trim().toUpperCase());

  let effectiveUserId: string | undefined;
  try {
    const stored = localStorage.getItem('aerowings_auth_user');
    if (stored) {
      effectiveUserId = JSON.parse(stored)?.id;
    }
  } catch {
    // ignore
  }

  const headers: Record<string, string> = {};
  if (effectiveUserId) {
    headers['x-user-id'] = effectiveUserId;
    headers['Authorization'] = `Bearer ${effectiveUserId}`;
    url.searchParams.set('userId', effectiveUserId);
  }

  const res = await fetch(url.toString(), { headers });
  if (!res.ok) throw new Error('Failed to retrieve bookings');
  return res.json();
}

export async function verifyTicketToken(token: string) {
  const res = await fetch(`${BASE_URL}/bookings/verify/${encodeURIComponent(token.trim())}`);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Ticket token could not be verified');
  return data;
}

export async function cancelBooking(id: string, reason?: string): Promise<{ success: boolean; booking: Booking; message?: string }> {
  const res = await fetch(`${BASE_URL}/bookings/${id}/cancel`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reason }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to cancel booking');
  return data;
}

export async function resendBookingEmail(id: string) {
  const res = await fetch(`${BASE_URL}/bookings/${id}/resend-email`, {
    method: 'POST',
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to dispatch email');
  return data;
}

export async function fetchAdminStats(adminEmail?: string) {
  const headers: Record<string, string> = {};
  if (adminEmail) headers['x-admin-email'] = adminEmail;
  const res = await fetch(`${BASE_URL}/admin/stats`, { headers });
  if (!res.ok) throw new Error('Failed to retrieve admin statistics');
  return res.json();
}

export async function fetchAdminEmails(adminEmail?: string): Promise<EmailLog[]> {
  const headers: Record<string, string> = {};
  if (adminEmail) headers['x-admin-email'] = adminEmail;
  const res = await fetch(`${BASE_URL}/admin/emails`, { headers });
  if (!res.ok) throw new Error('Failed to retrieve email logs');
  return res.json();
}

export async function addAdminFlight(flightData: any, adminEmail?: string): Promise<Flight> {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (adminEmail) headers['x-admin-email'] = adminEmail;
  const res = await fetch(`${BASE_URL}/admin/flights`, {
    method: 'POST',
    headers,
    body: JSON.stringify(flightData),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to create flight');
  return data;
}

export async function updateAdminFlight(id: string, updates: { status?: string; gate?: string }, adminEmail?: string): Promise<Flight> {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (adminEmail) headers['x-admin-email'] = adminEmail;
  const res = await fetch(`${BASE_URL}/admin/flights/${id}`, {
    method: 'PATCH',
    headers,
    body: JSON.stringify(updates),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to update flight');
  return data;
}

// Development Email Test Lab API methods
export async function fetchDevEmailTemplates() {
  const res = await fetch(`${BASE_URL}/dev/email-templates`);
  if (!res.ok) throw new Error('Failed to load email templates');
  return res.json();
}

export async function testDispatchEmail(payload: {
  templateType: string;
  targetEmail: string;
  mode: 'SIMULATED' | 'REAL_RESEND_TEST_RECIPIENT';
}) {
  const res = await fetch(`${BASE_URL}/dev/test-dispatch`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  return data;
}

export async function testOtpLifecycle(email?: string) {
  const res = await fetch(`${BASE_URL}/dev/test-otp-lifecycle`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to test OTP lifecycle');
  return data;
}

export async function fetchRecipientAudit() {
  const res = await fetch(`${BASE_URL}/dev/recipient-mapping-audit`);
  if (!res.ok) throw new Error('Failed to load recipient mapping audit');
  return res.json();
}

