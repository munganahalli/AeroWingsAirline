import React from 'react';
import { Check } from 'lucide-react';
import type { BookingStep } from '../../types/index.ts';

interface StepIndicatorProps {
  currentStep: BookingStep;
  onStepClick: (step: BookingStep) => void;
  maxAccessibleStep: BookingStep;
}

const STEPS: { number: BookingStep; label: string; description: string }[] = [
  { number: 1, label: 'Flight Selection', description: 'Choose flight route' },
  { number: 2, label: 'Traveler Details', description: 'Passenger information' },
  { number: 3, label: 'Seat Selection', description: 'Select aircraft seats' },
  { number: 4, label: 'Booking Confirmation', description: 'Review details' },
  { number: 5, label: 'Pay & Verify OTP', description: 'Payment & security' },
];

export function StepIndicator({ currentStep, onStepClick, maxAccessibleStep }: StepIndicatorProps) {
  return (
    <div className="w-full bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 mb-8 shadow-xs">
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
        {STEPS.map((step) => {
          const isCurrent = currentStep === step.number;
          const isCompleted = currentStep > step.number;
          const isClickable = step.number <= maxAccessibleStep;

          return (
            <button
              key={step.number}
              type="button"
              disabled={!isClickable}
              onClick={() => isClickable && onStepClick(step.number)}
              className={`text-left p-3 rounded-xl transition-all flex items-start gap-3 border ${
                isCurrent
                  ? 'bg-blue-50 border-blue-600 text-blue-950 shadow-xs ring-1 ring-blue-500'
                  : isCompleted
                  ? 'bg-slate-50 border-slate-200 text-slate-800 hover:bg-slate-100 cursor-pointer'
                  : 'bg-white border-transparent text-slate-400 cursor-not-allowed opacity-60'
              }`}
            >
              <div
                className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 transition-colors ${
                  isCurrent
                    ? 'bg-blue-900 text-white'
                    : isCompleted
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-200 text-slate-600'
                }`}
              >
                {isCompleted ? <Check className="w-4 h-4 stroke-[3]" /> : step.number}
              </div>
              <div className="min-w-0">
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                  Step {step.number}
                </div>
                <div
                  className={`text-xs font-bold truncate ${
                    isCurrent ? 'text-blue-950' : isCompleted ? 'text-slate-800' : 'text-slate-500'
                  }`}
                >
                  {step.label}
                </div>
                <div className="text-[10px] text-slate-400 truncate hidden sm:block">
                  {step.description}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
